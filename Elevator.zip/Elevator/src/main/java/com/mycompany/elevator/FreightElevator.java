package com.mycompany.Elevator;
public class FreightElevator extends Elevator{
    //int elevatorType = 3;
    //int maxPeople = 5;
    //int requestPriority = 5;

    FreightElevator(int maxPeople, int servicePriority) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    // Pass parametric data to arrayList
    public void FreightElevator(int maxPeople, int servicePriority){
        this.setMaxPeople(maxPeople);
        this.setServicePriority(servicePriority);
    }
    public FreightElevator(){
        this.servicePriority = 5;
        this.setMaxPeople(5);
    }
    public boolean isMoving() {
        // implement logic for determining if the elevator is currently moving
        return false;
    }

    @Override
    public boolean isAvailable() {
        // implement logic for determining if the elevator is currently available to take new passengers
        return false;
    }
}
