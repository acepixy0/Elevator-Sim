package com.mycompany.Elevator;

import java.util.ArrayList;
import java.util.List;

public class Elevator {
    private static int elevatorCounter = 0; // Number of elevator calls
    private int elevatorType = 0; // Numerical order: Standard, Express, Freight, Glass
    protected int servicePriority = 0; // Percentage of passenger requests for each elevator type
    private int maxPeople = 0; // Maximum amount of people allowed
    private int currentPeople = 0; //Number of passengers at any given time
    Elevator(){
        //elevatorCounter++; 
                    
    }

    /**
     * @return the elevatorCounter
     */
    public static int getElevatorCounter() {
        return elevatorCounter;
    }

    /**
     * @return the elevatorType
     */
    public int getElevatorType() {
        return elevatorType;
    }

    /**
     * @param elevatorType the elevatorType to set
     */
    public void setElevatorType(int elevatorType) {
        this.elevatorType = elevatorType;
    }

    /**
     * @return the servicePriority
     */
    public int getServicePriority() {
        return servicePriority;
    }

    /**
     * @param servicePriority the servicePriority to set
     */
    public void setServicePriority(int servicePriority) {
        this.servicePriority = servicePriority;
    }

    /**
     * @return the maxPeople
     */
    public int getMaxPeople() {
        return maxPeople;
    }

    /**
     * @param maxPeople the maxPeople to set
     */
    public void setMaxPeople(int maxPeople) {
        this.maxPeople = maxPeople;
    }

    /**
     * @return the currentPeople
     */
    public int getCurrentPeople() {
        return currentPeople;
    }

    /**
     * @param currentPeople the currentPeople to set
     */
    public void setCurrentPeople(int currentPeople) {
        this.currentPeople = currentPeople;
    }
    public boolean isAvailable() {
    return (this.getCurrentPeople() == 0 && !this.isMoving());
}

    private boolean isMoving() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    public Elevator requestElevator(int floor, List<Elevator> elevators) {
    // Create an array of available elevators
    List<Elevator> availableElevators = new ArrayList<>();
    for (Elevator elevator : elevators) {
        if (elevator.isAvailable()) {
            availableElevators.add(elevator);
        }
    }

    // Calculate the total service priority of available elevators
    int totalServicePriority = 0;
    for (Elevator elevator : availableElevators) {
        totalServicePriority += elevator.getServicePriority();
    }

    // Calculate the probability of selecting each available elevator
    List<Double> probabilities = new ArrayList<>();
    for (Elevator elevator : availableElevators) {
        double probability = (double) elevator.getServicePriority() / totalServicePriority;
        probabilities.add(probability);
    }

    // Select an elevator randomly based on the calculated probabilities
    double randomValue = Math.random();
    double cumulativeProbability = 0;
    for (int i = 0; i < availableElevators.size(); i++) {
        cumulativeProbability += probabilities.get(i);
        if (randomValue <= cumulativeProbability) {
            return availableElevators.get(i);
        }
    }

    // If no elevator is selected, return null
    return null;
}
}
    
    

