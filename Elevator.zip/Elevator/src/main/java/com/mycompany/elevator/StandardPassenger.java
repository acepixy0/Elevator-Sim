package com.mycompany.Elevator;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;



// Pass parametric data to arrayList
public class StandardPassenger extends Passenger {
    public StandardPassenger(int startFloor,int endFloor,int requestPriority) throws FileNotFoundException{
       this.startFloor = startFloor;
       this.endFloor = endFloor;
       this.requestPriority = requestPriority;
    }
    public StandardPassenger() {
    this.requestPriority = 70;    
}
    @Override
public boolean requestElevator(SimulatorSettings settings) {
    StandardElevator elevator = null;
    Random rand = new Random();
    Simulation sim = new Simulation();
    for (Elevator e : sim.elevators) {
        if (e instanceof StandardElevator standardElevator) {
            elevator = standardElevator;
            break;
        }
    }
    // Set the maximum number of people
    elevator.setMaxPeople(10); 
    // Check if there is enough space in the elevator
    if (passengerCounter >= elevator.getMaxPeople()) { 
        System.out.println("Not enough space....");
        return false;
    }
    // Add a passenger to the elevator
    passengerCounter += 1; 
    elevator.setCurrentPeople(passengerCounter);
    System.out.println("Number of passengers: " + passengerCounter);
    int noFloors = settings.getNoFloors();
    do {
        // Generate a random starting floor
        this.startFloor = rand.nextInt(noFloors); 
        // Generate a random ending floor
        this.endFloor = rand.nextInt(noFloors); 
    } 
    // Loop until the starting and ending floors are not the same
    while (this.startFloor == this.endFloor); 
        System.out.println("Initial floor = " + this.startFloor);
        System.out.println("Ending floor = " + this.endFloor);
        // Set the current floor to the starting floor
        settings.setCurrentFloor(this.startFloor); 
    // Move the elevator to the ending floor
    while (settings.getCurrentFloor() != this.endFloor) { 
        if (settings.getCurrentFloor() < this.endFloor) {
            System.out.println("Rising....");
            settings.setCurrentFloor(settings.getCurrentFloor() + 1);
        } else {
            System.out.println("Descending....");
            settings.setCurrentFloor(settings.getCurrentFloor() - 1);
        }
    }
    System.out.println("Here is your stop.");
    // Remove a passenger from the elevator
    passengerCounter -= 1; 
    elevator.setCurrentPeople(passengerCounter);
    return true;
}
public boolean requestElevator(StandardPassenger passenger) {
    Random rand = new Random();
    int priority = rand.nextInt(101);
    if (priority > this.requestPriority) {
        System.out.println("Passenger did not meet the priority threshold.");
        return false;
    }
    return true;
}
}
