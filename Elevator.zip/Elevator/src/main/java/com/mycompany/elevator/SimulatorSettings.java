package com.mycompany.Elevator;
public class SimulatorSettings {
    private int noFloors = 0;
    private int noElevators = 0;
    private int noSimulation = 0;
    private int currentFloor = 0; 
    SimulatorSettings(String file){
        
    }
    
    public int getNoFloors() {
        return noFloors;
    }

    public void setNoFloors(int noFloors) {
        this.noFloors = noFloors;
    }

    /**
     * @return the noElevators
     */
    public int getNoElevators() {
        return noElevators;
    }

    /**
     * @param noElevators the noElevators to set
     */
    public void setNoElevators(int noElevators) {
        this.noElevators = noElevators;
    }

    /**
     * @return the noSimulation
     */
    public int getNoSimulation() {
        return noSimulation;
    }

    /**
     * @param noSimulation the noSimulation to set
     */
    public void setNoSimulation(int noSimulation) {
        this.noSimulation = noSimulation;
    }

    /**
     * @return the currentFloor
     */
    public int getCurrentFloor() {
        return currentFloor;
    }

    /**
     * @param currentFloor the currentFloor to set
     */
    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }
}
