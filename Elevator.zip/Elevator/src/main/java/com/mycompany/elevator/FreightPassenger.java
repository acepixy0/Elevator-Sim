package com.mycompany.Elevator;
import java.util.Random;

public class FreightPassenger extends Passenger {

    FreightPassenger(int startFloor, int endFloor, int requestPriority) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    // Pass parametric data to arrayList
    public void FreightPassenger(int startFloor,int endFloor,int requestPriority){
       this.startFloor = startFloor;
       this.endFloor = endFloor;
       this.setRequestPriority(requestPriority);
    }
    public FreightPassenger() {
    this.requestPriority = 15;
    }
    //Unutilized
    public boolean requestElevator(SimulatorSettings settings) {
    FreightElevator elevator = null;
    Random rand = new Random();
    Simulation sim = new Simulation();
    for (Elevator e : sim.elevators) {
        if (e instanceof FreightElevator freightElevator) {
            elevator = freightElevator;
            break;
        }
    }
    // Set the maximum number of people
    elevator.setMaxPeople(5); 
    // Check if there is enough space in the elevator
    if (passengerCounter >= elevator.getMaxPeople()) { 
        System.out.println("Not enough space....");
        return false;
    }
    // Add a passenger to the elevator
    passengerCounter += 1; 
    elevator.setCurrentPeople(passengerCounter);
    System.out.println("Number of passengers: " + passengerCounter);
    int noFloors = settings.getNoFloors();
    do {
        // Generate a random starting floor
        this.startFloor = rand.nextInt(noFloors); 
        // Generate a random ending floor
        this.endFloor = rand.nextInt(noFloors); 
    } 
    // Loop until the starting and ending floors are not the same
    while (this.startFloor == this.endFloor); 
        System.out.println("Initial floor = " + this.startFloor);
        System.out.println("Ending floor = " + this.endFloor);
        // Set the current floor to the starting floor
        settings.setCurrentFloor(this.startFloor); 
    // Move the elevator to the ending floor
    while (settings.getCurrentFloor() != this.endFloor) { 
        if (settings.getCurrentFloor() < this.endFloor) {
            System.out.println("Rising....");
            settings.setCurrentFloor(settings.getCurrentFloor() + 1);
        } else {
            System.out.println("Descending....");
            settings.setCurrentFloor(settings.getCurrentFloor() - 1);
        }
    }
    System.out.println("Here is your stop.");
    // Remove a passenger from the elevator
    passengerCounter -= 1; 
    elevator.setCurrentPeople(passengerCounter);
    return true;
}
public boolean requestElevator(StandardPassenger passenger) {
    Random rand = new Random();
    int priority = rand.nextInt(101);
    if (priority > this.requestPriority) {
        System.out.println("Passenger did not meet the priority threshold.");
        return false;
    }
    return true;
}
}