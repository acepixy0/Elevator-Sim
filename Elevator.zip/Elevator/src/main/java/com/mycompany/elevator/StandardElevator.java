package com.mycompany.Elevator;
public class StandardElevator extends Elevator{

    StandardElevator(int maxPeople, int servicePriority) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    //int elevatorType = 1;
    //int maxPeople = 10;
    //int requestPriority = 70;
    
    // Pass parametric data to arrayList
    public void StandardElevator(int maxPeople, int servicePriority){
        this.setMaxPeople(maxPeople);
        this.setServicePriority(servicePriority);
    }
    public StandardElevator(){
        this.servicePriority = 70;
        this.setMaxPeople(10);
    }
    public boolean isMoving() {
        // implement logic for determining if the elevator is currently moving
        return false;
    }

    @Override
    public boolean isAvailable() {
        // implement logic for determining if the elevator is currently available to take new passengers
        return false;
    }
    
}
