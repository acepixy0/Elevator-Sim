package com.mycompany.Elevator;
public class ExpressElevator extends Elevator{
    //int elevatorType = 2;
    //int maxPeople = 8;
    //int requestPriority = 20;

    ExpressElevator(int maxPeople, int servicePriority) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    // Pass parametric data to arrayList
    public void ExpressElevator(int maxPeople, int servicePriority){
        this.setMaxPeople(maxPeople);
        this.setServicePriority(servicePriority);
    }
    public ExpressElevator(){
        this.servicePriority = 20;
        this.setMaxPeople(8);
    }
    public boolean isMoving() {
        // implement logic for determining if the elevator is currently moving
        return false;
    }

    @Override
    public boolean isAvailable() {
        // implement logic for determining if the elevator is currently available to take new passengers
        return false;
    }
}
