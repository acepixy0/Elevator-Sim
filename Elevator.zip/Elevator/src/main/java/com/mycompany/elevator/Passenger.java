package com.mycompany.Elevator;
public abstract class Passenger{

    public static int passengerCounter = 0;
    private String passengerID = "";
    protected int startFloor = 0;
    protected int endFloor = 0;
    protected int requestPriority = 0;
    
    public Passenger(){
        this.passengerID = "ID: " + passengerCounter;
        passengerCounter++;
        
    }
    
    /**
     * @return the requestPriority
     */
    public int getRequestPriority() {
        return requestPriority;
    }

    /**
     * @param requestPriority the requestPriority to set
     */
    public void setRequestPriority(int requestPriority) {
        this.requestPriority = requestPriority;
    }
    public abstract boolean requestElevator(SimulatorSettings settings);
}
