package com.mycompany.Elevator;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Simulation {
    SimulatorSettings settings = new SimulatorSettings("settings.txt");
    SimulatorSettings simSettings = new SimulatorSettings("simSettings.txt");
    ArrayList<Passenger> passengers = new ArrayList<>();
    ArrayList<Elevator> elevators = new ArrayList<>();
    //Sample of Elevator running
    public void InitSimulation(){
        Random random = new Random();
        simSettings.setNoElevators(random.nextInt(8) + 1);
        simSettings.setNoFloors(random.nextInt(100) + 1);
        simSettings.setNoSimulation(random.nextInt(150) + 1);
        int numElevators = simSettings.getNoElevators();
        //Iterate to randomly establish number of elevator types, does not go over 8
        for (int i = 0; i < numElevators; i++) {
            Elevator elevator;
            int elevatorType = random.nextInt(4) + 1;
            switch (elevatorType){
                case 1:
                    elevator = new StandardElevator();
                    break;
                case 2:
                    elevator = new ExpressElevator();
                    break;
                case 3:
                    elevator = new FreightElevator();
                    break;
                case 4:
                    elevator = new GlassElevator();
                    break;
                default:
                    throw new RuntimeException("Invalid elevator type");
            }
            elevators.add(elevator);
        }
        //Iterates amount of random number of iterations, adding various type of passengers based on limmited number of elevators and space.
        for(int i = 0; i < simSettings.getNoSimulation(); i++){
            Passenger passenger;
            int passengerType = random.nextInt(4) + 1;
            switch (passengerType){
                case 1 -> {
                    passenger = new StandardPassenger();   
                }
                case 2 -> {
                    passenger = new VipPassenger();    
                }
                case 3 -> {
                    passenger = new FreightPassenger();       
                }
                case 4 -> {
                    passenger = new GlassPassenger();
                }
                default -> throw new RuntimeException("Invalid passenger type");
                }
            boolean assignedToElevator = false;
            for (Elevator elevator : elevators) {
                if (elevator.isAvailable()) {
                    assignedToElevator = true;
                    passenger.requestElevator(simSettings);
                    break;
                }
            }
            if (!assignedToElevator) {
                System.out.println("No available elevators, could not assign passenger.");
            }
            passengers.add(passenger);
        }
        //Print elevator and passenger info
        System.out.println("Elevators:");
        for (Elevator elevator : elevators) {
            System.out.println(elevator.toString());
        }
        
        System.out.println("Passengers:");
        for (Passenger passenger : passengers) {
            System.out.println(passenger.toString());
        }
    }
}
        

    /*
    //Reads from file and execute
    public void FileEx() throws FileNotFoundException{
        File file = new File("C:\\Users\\Nathan J. Hagood\\Documents\\School Work\\Elevator\\src\\main\\java\\com\\mycompany\\elevator\\settings.txt");// Read all parameters from the file and store in the class
        Scanner scanner = new Scanner(file);
        scanner.useDelimiter(" ");
        int stringToNum = 0;
        
        //Iterating with number of simulations
        for(int i = 0; i <= settings.getNoSimulation(); i++){
        
            //While scanner can read a next line and implement arguments for ArrayList
            while(scanner.hasNextLine()){
                String line = scanner.nextLine().trim();
                System.out.println(line);
                //Determining number of floors
                if (line.startsWith("floors")){
                    String[] segment = line.split("\\s+");
                    // Chopping up data into sgments saved into an array
                    if (segment.length >= 2){ 
                        String numString = segment[1].trim();
                        try{
                            stringToNum = Integer.parseInt(numString);
                            System.out.println("Number of floors: " + stringToNum);
                            settings.setNoFloors(stringToNum);
                            System.out.println(settings.getNoFloors());
                        }
                        //Error out
                        catch(NumberFormatException e){
                        System.out.println("Invalid line format for number of floors: " + line);
                        }
                    }
                }
                //Adding passenger type to arrayList
                if(line.startsWith("add_passenger")){
                    int startFloor = 0;
                    int endFloor = 0;
                    int requestPriority = 0;
                    String passenger = "";
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 4) { 
                        try {
                            passenger = segment[4].trim();
                            startFloor = Integer.parseInt(segment[3].trim());
                            endFloor = Integer.parseInt(segment[4].trim()); 
                            requestPriority = Integer.parseInt(segment[5].trim());
                        } 
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for passenger details: " + line);
                            continue;
                        }
                        //Determine passenger type
                        switch (passenger) {
                            case "Standard" -> passengers.add(new StandardPassenger(startFloor, endFloor, requestPriority));
                            case "VIP" -> passengers.add(new VipPassenger(startFloor, endFloor, requestPriority));
                            case "Freight" -> passengers.add(new FreightPassenger(startFloor, endFloor, requestPriority));
                            case "Glass" -> passengers.add(new GlassPassenger(startFloor, endFloor, requestPriority));
                            default -> {
                            }
                        }  
                    }  
                }
                
                //Adding elevator type to arrayList
                if(line.startsWith("elevator_type")){
                    int maxPeople = 0;
                    int servicePriority = 0;
                    String elevator = "";
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 4) { 
                        try {
                            elevator = segment[1].trim();
                            maxPeople = Integer.parseInt(segment[2].trim());
                            servicePriority = Integer.parseInt(segment[3].trim());
                        } 
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for elevator details: " + line);
                            continue;
                        }
                    //Determine the elevator type
                    switch (elevator){
                        case "StandardElevator" -> elevators.add(new StandardElevator(maxPeople, servicePriority));
                        case "ExpressElevator" -> elevators.add(new ExpressElevator(maxPeople, servicePriority));
                        case "FreightElevator" -> elevators.add(new FreightElevator(maxPeople, servicePriority));
                        case "GlassElevator" -> elevators.add(new GlassElevator(maxPeople, servicePriority));
                        default -> {
                        }
                    }
                    }
                }
                //Adding request percentage of elevator
                if(line.startsWith("request_percentage")){
                    int requestPercentage = 0;
                    String elevator = "";
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 3){ 
                        try {
                            elevator = segment[1].trim();
                            requestPercentage = Integer.parseInt(segment[2].trim());
                        } 
                        //Error out
                        catch (NumberFormatException e){
                            System.out.println("Invalid line format for request percentage details: " + line);
                            continue;
                        }
                        //Determine the elevator type request percentage
                        switch (elevator){
                        case "StandardElevator":
                            StandardElevator type1 = new StandardElevator();
                            type1.setServicePriority(requestPercentage);
                        case "ExpressElevator": 
                            ExpressElevator type2 = new ExpressElevator();
                            type2.setServicePriority(requestPercentage);
                        case "FreightElevator":
                            FreightElevator type3 = new FreightElevator();
                            type3.setServicePriority(requestPercentage);
                        case "GlassElevator":
                            GlassElevator type4 = new GlassElevator();
                            type4.setServicePriority(requestPercentage);
                    }
                    }
                }
                //Adding passenger request percentage
                if(line.startsWith("passenger_request_percentage")){
                    int passengerRequestPercentage = 0;
                    String passenger = "";
                    String[] segment = line.split("\\s+");
                    
                    //Chopping up data stream
                    if (segment.length >= 3){ 
                        try {
                            passenger = segment[1].trim();
                            passengerRequestPercentage = Integer.parseInt(segment[2].trim());
                        } 
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for passenger request percentage details: " + line);
                            continue;
                        }
                        //Determine the passenger type request percentage
                        switch (passenger){
                        case "Standard":
                            StandardPassenger type1 = new StandardPassenger();
                            type1.setRequestPriority(passengerRequestPercentage);
                        case "VIP": 
                            VipPassenger type2 = new VipPassenger();
                            type2.setRequestPriority(passengerRequestPercentage);
                        case "Freight":
                            FreightPassenger type3 = new FreightPassenger();
                            type3.setRequestPriority(passengerRequestPercentage);
                        case "Glass":
                            GlassPassenger type4 = new GlassPassenger();
                            type4.setRequestPriority(passengerRequestPercentage);
                    }
                    }
                }
                //Setting number of elevators
                if(line.startsWith("number_of_elevators")){
                    int noElevators = Integer.parseInt(line.split(" ")[1].trim());
                    settings.setNoElevators(noElevators);
                }
                //Setting number of iterations
                if(line.startsWith("run_simulation")){
                    int noSimulation = Integer.parseInt(line.split(" ")[1].trim());
                    settings.setNoSimulation(noSimulation);
                }
            }  
        }//Bracket for loop
    }
}

*/

