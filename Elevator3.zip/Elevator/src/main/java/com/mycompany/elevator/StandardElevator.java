package com.mycompany.Elevator;

import java.util.ArrayList;
import java.util.List;

public class StandardElevator extends Elevator{
    // Pass parametric data to arrayList
    public void StandardElevator(int maxCapacity, int servicePriority){
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    public void StandardElevator(){
        this.setServicePriority(70);
        this.setMaxCapacity(10);
        this.getId();
    }
}
