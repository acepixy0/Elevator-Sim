package com.mycompany.Elevator;
public class GlassElevator extends Elevator{
    
    // Pass parametric data to arrayList
    public void GlassElevator(int maxPeople, int servicePriority){
    }
    public void GlassElevator(){
        this.setServicePriority(5);
        this.setMaxCapacity(6);
        this.getId();
    }
}
