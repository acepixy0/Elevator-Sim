package com.mycompany.Elevator;
import java.util.Random;

public class VipPassenger extends Passenger {

    // Pass parametric data to arrayList
    public VipPassenger(int startFloor,int endFloor){
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(5);
    }
    public VipPassenger() {
    this.setRequestPriority(5);
}

    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

