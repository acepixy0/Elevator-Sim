package com.mycompany.Elevator;
public class ExpressElevator extends Elevator{

    // Pass parametric data to arrayList
    public void ExpressElevator(int maxPeople, int servicePriority){
    }
    public void ExpressElevator(){
        this.setServicePriority(20);
        this.setMaxCapacity(8);
        this.getId();
    }
}
