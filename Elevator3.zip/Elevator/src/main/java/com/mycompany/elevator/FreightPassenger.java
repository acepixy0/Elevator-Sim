package com.mycompany.Elevator;
import java.util.Random;

public class FreightPassenger extends Passenger {
    // Pass parametric data to arrayList
    public FreightPassenger(int startFloor,int endFloor){
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(15);
    }
    public FreightPassenger() {
    this.setRequestPriority(15);
    }

    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}