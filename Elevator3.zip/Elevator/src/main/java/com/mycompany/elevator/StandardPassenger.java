package com.mycompany.Elevator;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

// Pass parametric data to arrayList
public class StandardPassenger extends Passenger {
    public StandardPassenger(int startFloor,int endFloor){
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(70);
    }
    public StandardPassenger() {
    this.setRequestPriority(70);
}

    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
