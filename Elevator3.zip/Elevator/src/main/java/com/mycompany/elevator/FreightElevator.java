package com.mycompany.Elevator;
public class FreightElevator extends Elevator{

    // Pass parametric data to arrayList
    public void FreightElevator(int maxPeople, int servicePriority){
    }
    public void FreightElevator(){
        this.setServicePriority(5);
        this.setMaxCapacity(5);
        this.getId();
    }
    
}
