
package com.mycompany.elevator;

/**
 *
 * @author Nathan J. Hagood
 */
public class Building {
    Building() {
    
    }
}
