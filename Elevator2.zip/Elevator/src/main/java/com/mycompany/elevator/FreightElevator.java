package com.mycompany.Elevator;
public class FreightElevator extends Elevator{
    private boolean isMoving;
    private boolean isDoorOpen;
    private boolean isStopped;
    private boolean isAvaliable;
    private Passenger passenger;

    FreightElevator(int id) {
        super(id);
    }
    // Pass parametric data to arrayList
    public void FreightElevator(int maxPeople, int servicePriority){
    }
    public void FreightElevator(){
        this.setServicePriority(5);
        this.setMaxCapacity(5);
        
    }
    @Override
    public boolean isMoving() {
        return isMoving;
    }
    
    @Override
    public boolean isAvailable() {
        // implement logic for determining if the elevator is currently available to take new passengers
        return false;
    }

    @Override
    public void move() {
        if (!isDoorOpen && !isMoving) {
            System.out.println("Elevator " + getId() + " is moving.");
            isMoving = true;
            isStopped = false; 
            isAvaliable = false;
        }
        if (!getVisitNextFloor().isEmpty()) {
            int closestFloor = findClosestFloor();
            // go to the closest floor
            setCurrentFloor(closestFloor);
        }
    }

    @Override
    public void stop() {
        if (isMoving) {
            System.out.println("Elevator " + getId() + " has stopped.");
            isMoving = false;
            isStopped = true;
            isAvaliable = true;
        }
    }

    @Override
    public void openDoor() {
        if (!isDoorOpen && !isMoving && isStopped) {
            System.out.println("Elevator " + getId() + " doors are open.");
            isMoving = false;
            isStopped = true;
            isDoorOpen = true;
            isAvaliable = true;
            this.removePassenger(passenger);
        }
    }

    @Override
    public void closeDoor() {
        if (isDoorOpen && !isMoving && isAvaliable) {
            System.out.println("Elevator " + getId() + " doors are closed.");
            isMoving = false;
            isStopped = true;
            isDoorOpen = false;
            isAvaliable = false;
        }
    }
}
