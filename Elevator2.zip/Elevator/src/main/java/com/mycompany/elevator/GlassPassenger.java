package com.mycompany.Elevator;
import java.util.Random;

public class GlassPassenger extends Passenger {

    GlassPassenger(int startFloor, int endFloor, int requestPriority) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    // Pass parametric data to arrayList
    public void GlassPassenger(int startFloor,int endFloor,int requestPriority){
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
    }
    public GlassPassenger() {
    this.requestPriority = 5;
}
    //Unutilized
    @Override
    public boolean requestElevator(SimulatorSettings settings) {
    GlassElevator elevator = null;
    Random rand = new Random();
    Simulation sim = new Simulation();
    for (Elevator e : sim.elevators) {
        if (e instanceof GlassElevator glassElevator) {
            elevator = glassElevator;
            break;
        }
    }
    // Set the maximum number of people
    elevator.setMaxPeople(6); 
    // Check if there is enough space in the elevator
    if (getPassengerCounter() >= elevator.getMaxPeople()) { 
        System.out.println("Not enough space....");
        return false;
    }
    // Add a passenger to the elevator
    passengerCounter += 1; 
    elevator.setCurrentPeople(getPassengerCounter());
    System.out.println("Number of passengers: " + getPassengerCounter());
    int noFloors = settings.getNoFloors();
    do {
        // Generate a random starting floor
        this.setStartFloor(rand.nextInt(noFloors)); 
        // Generate a random ending floor
        this.setEndFloor(rand.nextInt(noFloors)); 
    } 
    // Loop until the starting and ending floors are not the same
    while (this.getStartFloor() == this.getEndFloor()); 
        System.out.println("Initial floor = " + this.getStartFloor());
        System.out.println("Ending floor = " + this.getEndFloor());
        // Set the current floor to the starting floor
        settings.setCurrentFloor(this.getStartFloor()); 
    // Move the elevator to the ending floor
    while (settings.getCurrentFloor() != this.getEndFloor()) { 
        if (settings.getCurrentFloor() < this.getEndFloor()) {
            System.out.println("Rising....");
            settings.setCurrentFloor(settings.getCurrentFloor() + 1);
        } else {
            System.out.println("Descending....");
            settings.setCurrentFloor(settings.getCurrentFloor() - 1);
        }
    }
    System.out.println("Here is your stop.");
    // Remove a passenger from the elevator
    passengerCounter -= 1; 
    elevator.setCurrentPeople(getPassengerCounter());
    return true;
}
public boolean requestElevator(StandardPassenger passenger) {
    Random rand = new Random();
    int priority = rand.nextInt(101);
    if (priority > this.requestPriority) {
        System.out.println("Passenger did not meet the priority threshold.");
        return false;
    }
    return true;
}
}
