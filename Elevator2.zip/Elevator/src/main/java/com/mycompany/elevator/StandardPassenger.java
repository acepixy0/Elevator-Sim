package com.mycompany.Elevator;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;



// Pass parametric data to arrayList
public class StandardPassenger extends Passenger {
    public StandardPassenger(int startFloor,int endFloor,int requestPriority) throws FileNotFoundException{
       
    }
    public StandardPassenger() {
    this.setRequestPriority(70);
}
    @Override
public boolean requestElevator(SimulatorSettings settings) {
    StandardElevator elevator = null;
    Random rand = new Random();
    Simulation sim = new Simulation();
    for (Elevator e : sim.elevators) {
        if (e instanceof StandardElevator standardElevator) {
            elevator = standardElevator;
            break;
        }
    }
  
    // Check if there is enough space in the elevator
    if (getPassengerCounter() >= elevator.getMaxCapacity()) { 
        
        return false;
    }
    // Add a passenger to the elevator
    
    elevator.setCurrentPeople(getPassengerCounter());
    System.out.println("Number of passengers: " + getPassengerCounter());
    int noFloors = settings.getNoFloors();
    do {
        // Generate a random starting floor
        this.setStartFloor(rand.nextInt(noFloors)); 
        // Generate a random ending floor
        this.setEndFloor(rand.nextInt(noFloors)); 
    } 
    // Loop until the starting and ending floors are not the same
    while (this.getStartFloor() == this.getEndFloor()); 
        System.out.println("Initial floor = " + this.getStartFloor());
        System.out.println("Ending floor = " + this.getEndFloor());
        // Set the current floor to the starting floor
        settings.setCurrentFloor(this.getStartFloor()); 
    // Move the elevator to the ending floor
    while (settings.getCurrentFloor() != this.getEndFloor()) { 
        if (settings.getCurrentFloor() < this.getEndFloor()) {
            System.out.println("Rising....");
            settings.setCurrentFloor(settings.getCurrentFloor() + 1);
        } else {
            System.out.println("Descending....");
            settings.setCurrentFloor(settings.getCurrentFloor() - 1);
        }
    }
    
    // Remove a passenger from the elevator
    
    elevator.setCurrentPeople(getPassengerCounter());
    return true;
}
public boolean requestElevator(StandardPassenger passenger) {
    Random rand = new Random();
    int priority = rand.nextInt(101);
    if (priority > this.getRequestPriority()) {
        System.out.println("Passenger did not meet the priority threshold.");
        return false;
    }
    return true;
}
}
