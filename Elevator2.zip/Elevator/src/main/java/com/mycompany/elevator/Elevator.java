package com.mycompany.Elevator;

import java.util.ArrayList;
import java.util.List;

public abstract class Elevator {
    private static int elevatorCounter = 0; // Number of elevator calls
    private int elevatorType = 0; // Numerical order: Standard, Express, Freight, Glass
    private int servicePriority = 0; // Percentage of passenger requests for each elevator type
    private int maxCapacity = 0; // Maximum amount of people allowed
    private int currentNumPass = 0; //Number of passengers at any given time
    private int currentFloor = 0;
    private int id = 0;
    private boolean isAvailable = false;
    private ArrayList<Passenger> passengers;
    private List<Integer> visitNextFloor;
    
    Elevator(int id){
        this.id = id + elevatorCounter++;
        passengers = new ArrayList<>();
        visitNextFloor = new ArrayList<>();    
    }
    public void setCurrentFloor(int floor) {
        this.currentFloor = floor;
    }
     public int getCurrentFloor() {
        return currentFloor;
    }
     public boolean isAvailable() {
        return isAvailable;
    }
     public void setAvailable(boolean available) {
        isAvailable = available;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public static int getElevatorCounter() {
        return elevatorCounter;
    }
    public int getElevatorType() {
        return elevatorType;
    }
    public void setElevatorType(int elevatorType) {
        this.elevatorType = elevatorType;
    }
    public int getServicePriority() {
        return servicePriority;
    }
    public void setServicePriority(int servicePriority) {
        this.servicePriority = servicePriority;
    }
    public int getMaxCapacity() {
        return maxCapacity;
    }
    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }
    public int getCurrentPeople() {
        return currentNumPass;
    }
    public void setCurrentPeople(int currentPeople) {
        this.currentNumPass = currentPeople;
    }
    public List<Integer> getVisitNextFloor() {
        return visitNextFloor;
    }
    public int Direction(){
        return 0;
    }
    
    public boolean isMoving() {
        return false;
    }
    protected boolean addPassenger(Passenger passenger) {
        if (currentNumPass < maxCapacity){
            passengers.add(passenger);
            currentNumPass++;
            getVisitNextFloor().add(passenger.getStartFloor());
            getVisitNextFloor().add(passenger.getEndFloor());
            return true;
        }
        else{
            System.out.println("Not enough space....");
            return false;
        }
    }
    protected void removePassenger(Passenger passenger) {
        if(currentFloor == getVisitNextFloor().get(passenger.getEndFloor())){
            System.out.println("Here is your stop.");
            passengers.remove(passenger);
            currentNumPass--;
        }
    } 
    public boolean hasHigherPriorityThan(Elevator otherElevator) {
        return this.getServicePriority() > otherElevator.getServicePriority();
    }
    protected int findClosestFloor() {
        int closestFloor = -1;
        int closestDistance = Integer.MAX_VALUE;
        for (int floor : visitNextFloor) {
            int distance = Math.abs(currentFloor - floor);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestFloor = floor;
            }
        }
        return closestFloor;
    }
    @Override
    public String toString() {
        return "Elevator " + id + " [Current Floor=" + currentFloor + ", Capacity=" + currentNumPass + ", Available=" + isAvailable + "]";
    }
    public abstract void move();

    public abstract void stop();

    public abstract void openDoor();

    public abstract void closeDoor();   
}


    
    
   