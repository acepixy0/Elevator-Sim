package com.mycompany.Elevator;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Building{
    SimulatorSettings simSettings = new SimulatorSettings();
    SimulatorSettings settings = new SimulatorSettings("settings.txt");
    private ArrayList<Elevator> elevators;
    private ArrayList<Passenger> passengers;
    Random random = new Random();
    Elevator elevator;
    Passenger passenger;
    
    public Building(){
        
    }
    public void addFileElevator(int elevatorType, int numElevators){
        // Create elevators and add to list
        for (int i = 0; i < numElevators; i++) {
            elevatorType = random.nextInt(elevatorType) + 1;
            switch (elevatorType){
                case 1:
                    elevator = new StandardElevator();
                    break;
                case 2:
                    elevator = new ExpressElevator();
                    break;
                case 3:
                    elevator = new FreightElevator();
                    break;
                case 4:
                    elevator = new GlassElevator();
                    break;
                default:
                    throw new RuntimeException("Invalid elevator type");
            }
            elevators.add(elevator);
        }
    }
    public void addSimElevator(int elevatorType, int numElevators){
        // Create elevators and add to list
        for (int i = 0; i < numElevators; i++) {
            elevatorType = random.nextInt(elevatorType) + 1;
            switch (elevatorType){
                case 1:
                    elevator = new StandardElevator();
                    break;
                case 2:
                    elevator = new ExpressElevator();
                    break;
                case 3:
                    elevator = new FreightElevator();
                    break;
                case 4:
                    elevator = new GlassElevator();
                    break;
                default:
                    throw new RuntimeException("Invalid elevator type");
            }
            elevators.add(elevator);
        }
    }
    public void addFilePassenger(int passengerType, int startFloor, int endFloor, int numSim) {
        for(int i = 0; i < numSim; i++){
            switch (passengerType){
                case 1:
                    passenger = new StandardPassenger(startFloor, endFloor);
                    break;
                case 2:
                    passenger = new VipPassenger(startFloor, endFloor);
                    break;
                case 3:
                    passenger = new FreightPassenger(startFloor, endFloor);
                    break;
                case 4:
                    passenger = new GlassPassenger(startFloor, endFloor);
                    break;
                default:
                    throw new RuntimeException("Invalid passenger type");
            }
            passengers.add(passenger);
        }
    }
    public void addSimPassenger(int passengerType, int numSim) {
        for(int i = 0; i < numSim; i++){
            passengerType = random.nextInt(passengerType) + 1;
            int startFloor = random.nextInt(simSettings.getNoFloors() + 1);
            int endFloor = random.nextInt(simSettings.getNoFloors() + 1);
            switch (passengerType){
                case 1:
                    passenger = new StandardPassenger(startFloor, endFloor);
                    break;
                case 2:
                    passenger = new VipPassenger(startFloor, endFloor);
                    break;
                case 3:
                    passenger = new FreightPassenger(startFloor, endFloor);
                    break;
                case 4:
                    passenger = new GlassPassenger(startFloor, endFloor);
                    break;
                default:
                    throw new RuntimeException("Invalid passenger type");
            }
            passengers.add(passenger);
        }
    }
    public Elevator requestElevator(Passenger passenger) {
        int maxPriority = 0;
        Elevator selectedElevator = null;
    
        for (Elevator elevator : elevators) {
            if (elevator.isAvailable()) {
                int priority = (passenger.getRequestPriority() * elevator.getServicePriority()) + (passenger.getGenRequestPriority() * elevator.getGenServicePriority());
                if (priority > maxPriority) {
                    maxPriority = priority;
                    selectedElevator = elevator;
                }
            }
        }
        return selectedElevator;
    }

    public void runElevators(int numFloors) {
        int totalNumPassengers = passengers.size();
        int totalNumElevators = elevators.size();
        int maxIterations = totalNumPassengers * totalNumElevators * numFloors;
        int iterations = 0;
        
        // Simulate the elevator system running
        while (iterations < maxIterations) {
            boolean isAnyElevatorMoving = false;
            for (Elevator elevator : elevators) {
                if (elevator.isMoving()) {
                    isAnyElevatorMoving = true;

                    // Check for any waiting passengers who need to be picked up
                    List<Passenger> waitingPass = new ArrayList<>(passengers);
                    for (Passenger passenger : waitingPass) {
                        if (elevator.isAvailable() && passenger.getStartFloor() == elevator.getCurrentFloor() && elevator.getCurrentNumPass() < elevator.getMaxCapacity()) {
                            elevator.stop();
                            elevator.openDoor();
                            elevator.addPassenger(passenger);
                            passengers.remove(passenger);
                        }
                    }

                    // Check for any passengers in the elevator who need to be dropped off
                    List<Passenger> passengersInElevator = new ArrayList<>(elevator.getPassengers());
                    for (Passenger passenger : passengersInElevator) {
                        if (passenger.getEndFloor() == elevator.getCurrentFloor()) {
                        elevator.removePassenger(passenger);
                        }
                    }
                    // Move the elevator
                    elevator.closeDoor();
                    elevator.move();
                    ElevatorStatusLog logger = ElevatorStatusLog.getInstance();
                    logger.log("Elevator " + elevator.getId() + " is moving from floor " + elevator.getCurrentFloor() + " to floor " + elevator.findClosestFloor());
                    
                    // Open and close the elevator doors
                    if (!elevator.isMoving()) {
                        elevator.openDoor();
                        elevator.closeDoor();
                    }
                }
            }
            if (!isAnyElevatorMoving && passengers.isEmpty()) {
                break;
            }
            iterations++;
        }
    }

    void update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
