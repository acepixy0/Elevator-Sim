package com.mycompany.Elevator;

import java.util.Random;

public class ExpressElevator extends Elevator{
    Random random = new Random();
    
    ExpressElevator(int genServicePercentage) {
        this.setGenServicePriority(genServicePercentage);
    }

    // Pass parametric data to arrayList
    ExpressElevator(int maxCapacity, int servicePriority) {
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    ExpressElevator(){
        this.setGenServicePriority(random.nextInt(1, 20 + 1));
        this.setServicePriority(random.nextInt(1, 25 + 1));
        this.setMaxCapacity(random.nextInt(2, 10 + 1));
        this.getId();
    }
    ExpressElevator(ExpressElevator expressE){
        
    }
}
