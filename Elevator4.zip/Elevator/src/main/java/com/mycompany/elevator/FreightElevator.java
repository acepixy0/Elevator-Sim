package com.mycompany.Elevator;

import java.util.Random;

public class FreightElevator extends Elevator{
    Random random = new Random();
    
    FreightElevator(int genServicePercentage) {
        this.setGenServicePriority(genServicePercentage);
    }
    
    // Pass parametric data to arrayList
    FreightElevator(int maxCapacity, int servicePriority) {
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    FreightElevator(){
        this.setGenServicePriority(random.nextInt(1, 5 + 1));
        this.setServicePriority(random.nextInt(1, 20 + 1));
        this.setMaxCapacity(random.nextInt(2, 15 + 1));
        this.getId();
    }
    FreightElevator(FreightElevator freightE){
        
    }
}
