package com.mycompany.Elevator;

import java.util.ArrayList;
import java.util.List;

public class Elevator {
    private static int elevatorCounter = 0; // Number of elevator calls
    private int elevatorType = 0; // Numerical order: Standard, Express, Freight, Glass
    private int servicePriority = 0;
    private int genServicePriority = 0;// Percentage of passenger requests for each elevator type
    private int maxCapacity = 0; // Maximum amount of people allowed on elevator
    private int currentNumPass = 0; //Number of passengers at any given time
    private int currentFloor = 1;
    private int id = 0;
    private boolean isDoorOpen;
    private boolean isMoving;
    private boolean isStopped;
    private boolean isAvaliable;
    private boolean isAvailable = false;
    private ArrayList<Passenger> passengers;
    private List<Integer> visitNextFloor;
    
    
    Elevator(){
        this.id = id + elevatorCounter++;
        passengers = new ArrayList<>();
        visitNextFloor = new ArrayList<>();    
    }
    public void setCurrentFloor(int floor) {
        this.currentFloor = floor;
    }
     public int getCurrentFloor() {
        return currentFloor;
    }
     public boolean isAvailable() {
        return isAvailable;
    }
     public void setAvailable(boolean available) {
        isAvailable = available;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public static int getElevatorCounter() {
        return elevatorCounter;
    }
    public int getElevatorType() {
        return elevatorType;
    }
    public void setElevatorType(int elevatorType) {
        this.elevatorType = elevatorType;
    }
    public int getServicePriority() {
        return servicePriority;
    }
    public void setServicePriority(int servicePriority) {
        this.servicePriority = servicePriority;
    }
    public int getGenServicePriority() {
        return genServicePriority;
    }
    public void setGenServicePriority(int genServicePriority) {
        this.genServicePriority = genServicePriority;
    }
    public int getMaxCapacity() {
        return maxCapacity;
    }
    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }
    public int getCurrentNumPass() {
        return currentNumPass;
    }
    public void setCurrentNumPass(int currentNumPass) {
        this.currentNumPass = currentNumPass;
    }
    public List<Integer> getVisitNextFloor() {
        return visitNextFloor;
    }
    public int Direction(){
        return 0;
    }
    
    public boolean isMoving() {
        return isMoving;
    }
    public boolean addPassenger(Passenger passenger) {
        if (currentNumPass < maxCapacity){
            passengers.add(passenger);
            currentNumPass++;
            getVisitNextFloor().add(passenger.getStartFloor());
            getVisitNextFloor().add(passenger.getEndFloor());
            return true;
        }
        else{
            System.out.println("Not enough space....");
            return false;
        }
    }
    public void removePassenger(Passenger passenger) {
        if(currentFloor == getVisitNextFloor().get(passenger.getEndFloor())){
            System.out.println("Here is your stop.");
            passengers.remove(passenger);
            currentNumPass--;
        }
    }
    public ArrayList<Passenger> getPassengers() {
        return this.passengers;
    }
    public boolean hasHigherPriorityThan(Elevator otherElevator) {
        return this.getServicePriority() > otherElevator.getServicePriority();
    }
    public int findClosestFloor() {
        int closestFloor = -1;
        int closestDistance = Integer.MAX_VALUE;
        for (int floor : visitNextFloor) {
            int distance = Math.abs(currentFloor - floor);
            if (distance < closestDistance) {
                closestDistance = distance;
                closestFloor = floor;
            }
        }
        return closestFloor;
    }
    
    public void move(){
        if (!isDoorOpen && !isMoving) {
            System.out.println("Elevator " + this.getId()+ " is moving.");
            isMoving = true;
            isStopped = false; 
            isAvaliable = false;
        }
        if (!getVisitNextFloor().isEmpty()) {
            int closestFloor = findClosestFloor();
            // go to the closest floor
            setCurrentFloor(closestFloor);
        }
    }

    public void stop() {
        if (isMoving) {
            System.out.println("Elevator " + this.getId() + " has stopped.");
            isMoving = false;
            isStopped = true;
            isAvaliable = true;
        }
    }

    public void openDoor() {
        if (!isDoorOpen && !isMoving && isStopped) {
            System.out.println("Elevator " + this.getId() + " doors are open.");
            isMoving = false;
            isStopped = true;
            isDoorOpen = true;
            isAvaliable = true;
        }
    }

    public void closeDoor() {
        if (isDoorOpen && !isMoving && isAvaliable) {
            System.out.println("Elevator " + this.getId() + " doors are closed.");
            isMoving = false;
            isStopped = true;
            isDoorOpen = false;
            isAvaliable = false;
        }
    }  
    
    @Override
    public String toString() {
        return "Elevator " + id + " [Current Floor=" + currentFloor + ", Capacity=" + currentNumPass + ", Available=" + isAvailable + "]";
    }

    
    
}


    
    
   