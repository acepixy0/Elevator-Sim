package com.mycompany.Elevator;

import java.util.Random;

public class GlassElevator extends Elevator{
    Random random = new Random();
    
    GlassElevator(int genServicePercentage) {
        this.setGenServicePriority(genServicePercentage);
    }
    
// Pass parametric data to arrayList
    GlassElevator(int maxCapacity, int servicePriority) {
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    
    GlassElevator(){
        this.setGenServicePriority(random.nextInt(1, 5 + 1));
        this.setServicePriority(random.nextInt(1, 15 + 1));
        this.setMaxCapacity(random.nextInt(2, 6 + 1));
        this.getId();
    }
    GlassElevator(GlassElevator glassE){
        
    }
}
