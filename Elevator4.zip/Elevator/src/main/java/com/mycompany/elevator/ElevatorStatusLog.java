
package com.mycompany.Elevator;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author Nathan J. Hagood
 */
public class ElevatorStatusLog {
    private static ElevatorStatusLog instance;
    private File logFile;

    private ElevatorStatusLog() {
        // Create a log file
        logFile = new File("elevator-log.txt");
    }
    public static ElevatorStatusLog getInstance() {
        if (instance == null) {
            instance = new ElevatorStatusLog();
        }
        return instance;
    }
    public void log(String message) {
        try {
            // Append the message to the log file
            BufferedWriter writer = new BufferedWriter(new FileWriter(logFile, true));
            writer.write(message);
            writer.newLine();
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

