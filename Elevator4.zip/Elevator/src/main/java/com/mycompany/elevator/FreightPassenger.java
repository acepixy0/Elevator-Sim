package com.mycompany.Elevator;
import java.util.Random;

public class FreightPassenger extends Passenger {
    Random random = new Random();
    
    //Default
    FreightPassenger() {
    this.setRequestPriority(15);
    }
    FreightPassenger(int genRequestPercentage) {
        this.setGenRequestPriority(genRequestPercentage);
    }
    // Pass parametric data to arrayList
    FreightPassenger(int startFloor,int endFloor){
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(random.nextInt(1, 20 + 1));
       this.setGenRequestPriority(random.nextInt(1, 15 + 1));
    }
    //Used to store info from file read
    FreightPassenger(int startFloor, int endFloor, int requestPriority) {
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
    }
    FreightPassenger(FreightPassenger freightP){
        
    }

    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}