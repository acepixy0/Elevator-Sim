package com.mycompany.Elevator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Nathan J. Hagood
 */
public class ReadAndStore {
    private static final int TYPE_INDEX = 1;
    private static final int ELEVATOR_TYPE_INDEX = 1;
    private static final int NUMBER_OF_FLOORS_INDEX = 1;
    private static final int MAX_CAPACITY_INDEX = 2;
    private static final int GENERAL_PERCENTAGE_INDEX = 2;
    private static final int NUMBER_OF_ELEVATORS_INDEX = 2;
    private static final int NUMBER_OF_SIMULATIONS_INDEX = 2;
    private static final int START_FLOOR_INDEX = 3;
    private static final int SERVICE_PRIORITY_INDEX = 3;
    private static final int END_FLOOR_INDEX = 4;
    private static final int PASSENGER_TYPE_INDEX = 4;
    private static final int REQUEST_PRIORITY_INDEX = 5;
    
    SimulatorSettings settings = new SimulatorSettings("settings.txt");
    ArrayList<Passenger> passengers;
    ArrayList<Elevator> elevators ;
    Passenger passenger;
    Elevator elevator;
    
    //Reads from file and stores values
    public void ReadFromFile() throws FileNotFoundException{
        elevators = new ArrayList<>();
        passengers = new ArrayList<>();
        File file = new File("C:\\Users\\Nathan J. Hagood\\Documents\\School Work\\Elevator\\src\\main\\java\\com\\mycompany\\elevator\\settings.txt");// Read all parameters from the file and store in the class
        Scanner scanner = new Scanner(file);
        scanner.useDelimiter(" ");
        int stringToNum = 0;
        
        //Iterating with number of simulations
        //for(int i = 0; i <= settings.getNoSimulation(); i++){
        
            //While scanner can read a next line and implement arguments for ArrayList
            while(scanner.hasNextLine()){
                String line = scanner.nextLine().trim();
                System.out.println(line);
                //Determining number of floors
                if (line.startsWith("floors")){
                    String[] segment = line.split("\\s+");
                    // Chopping up data into sgments saved into an array
                    if (segment.length >= 2){ 
                        String numString = segment[NUMBER_OF_FLOORS_INDEX].trim();
                        try{
                            stringToNum = Integer.parseInt(numString);
                            System.out.println("Number of floors: " + stringToNum);
                            settings.setNoFloors(stringToNum);
                            System.out.println(settings.getNoFloors());
                        }
                        //Error out
                        catch(NumberFormatException e){
                        System.out.println("Invalid line format for number of floors: " + line);
                        break;
                        }
                    }
                }
                //Adding passenger type to arrayList
                if(line.startsWith("add_passenger")){
                    int startFloor = 0;
                    int endFloor = 0;
                    int requestPriority = 0;
                    String passenger = "";
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 4) { 
                        try {
                            passenger = segment[PASSENGER_TYPE_INDEX].trim();
                            startFloor = Integer.parseInt(segment[START_FLOOR_INDEX].trim());
                            endFloor = Integer.parseInt(segment[END_FLOOR_INDEX].trim()); 
                            requestPriority = Integer.parseInt(segment[REQUEST_PRIORITY_INDEX].trim());
                        } 
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for passenger details: " + line);
                            continue;
                        }
                        //Determine passenger type
                        switch (passenger) {
                            case "Standard":
                                passengers.add(new StandardPassenger(startFloor, endFloor, requestPriority));
                                break;
                            case "VIP":
                                passengers.add(new VipPassenger(startFloor, endFloor, requestPriority));
                                break;
                            case "Freight":
                                passengers.add(new FreightPassenger(startFloor, endFloor, requestPriority));
                                break;
                            case "Glass":
                                passengers.add(new GlassPassenger(startFloor, endFloor, requestPriority));
                                break;
                            default:{
                                break;
                            }
                        }  
                        passengers.add(this.passenger);
                    }  
                }
                
                //Adding elevator type to arrayList
                if(line.startsWith("elevator_type")){
                    int maxCapacity = 0;
                    int servicePriority = 0;
                    String elevator = "";
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 4) { 
                        try {
                            elevator = segment[ELEVATOR_TYPE_INDEX].trim();
                            maxCapacity = Integer.parseInt(segment[MAX_CAPACITY_INDEX].trim());
                            servicePriority = Integer.parseInt(segment[SERVICE_PRIORITY_INDEX].trim());
                        } 
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for elevator details: " + line);
                            continue;
                        }
                    //Determine the elevator type
                    switch (elevator){
                        case "StandardElevator":
                            elevators.add(new StandardElevator(maxCapacity, servicePriority));
                            break;
                        case "ExpressElevator":
                            elevators.add(new ExpressElevator(maxCapacity, servicePriority));
                            break;
                        case "FreightElevator":
                            elevators.add(new FreightElevator(maxCapacity, servicePriority));
                            break;
                        case "GlassElevator":
                            elevators.add(new GlassElevator(maxCapacity, servicePriority));
                            break;
                        default:{
                            break;
                        }
                    }
                    }
                    elevators.add(this.elevator);
                }
                //Adding request percentage of elevator
                if(line.startsWith("request_percentage")){
                    int genServicePercentage = 0;
                    String elevator = "";
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 3){ 
                        try {
                            elevator = segment[TYPE_INDEX].trim();
                            genServicePercentage = Integer.parseInt(segment[GENERAL_PERCENTAGE_INDEX ].trim());
                        } 
                        //Error out
                        catch (NumberFormatException e){
                            System.out.println("Invalid line format for request percentage details: " + line);
                            continue;
                        }
                        //Determine the elevator type request percentage
                        switch (elevator){
                        case "StandardElevator":
                            StandardElevator e1 = new StandardElevator(genServicePercentage);
                            break;
                        case "ExpressElevator": 
                            ExpressElevator e2 = new ExpressElevator(genServicePercentage);
                            break;
                        case "FreightElevator":
                            FreightElevator e3 = new FreightElevator(genServicePercentage);
                            break;
                        case "GlassElevator":
                            GlassElevator e4 = new GlassElevator(genServicePercentage);
                            break;
                    }
                    }
                }
                //Adding passenger request percentage
                if(line.startsWith("passenger_request_percentage")){
                    int genRequestPercentage = 0;
                    String passenger = "";
                    String[] segment = line.split("\\s+");
                    
                    //Chopping up data stream
                    if (segment.length >= 3){ 
                        try {
                            passenger = segment[TYPE_INDEX].trim();
                            genRequestPercentage = Integer.parseInt(segment[GENERAL_PERCENTAGE_INDEX].trim());
                            continue;
                        } 
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for passenger request percentage details: " + line);
                        }
                        //Determine the passenger type request percentage
                        switch (passenger){
                        case "Standard":
                            StandardPassenger p1 = new StandardPassenger(genRequestPercentage);
                            break;
                        case "VIP": 
                            VipPassenger p2 = new VipPassenger(genRequestPercentage);
                            break;
                        case "Freight":
                            FreightPassenger p3 = new FreightPassenger(genRequestPercentage);
                            break;
                        case "Glass":
                            GlassPassenger p4 = new GlassPassenger(genRequestPercentage);
                            break;
                    }
                    }
                }
                //Setting number of elevators
                if(line.startsWith("number_of_elevators")){
                    int noElevators = Integer.parseInt(line.split(" ")[NUMBER_OF_ELEVATORS_INDEX].trim());
                    settings.setNoElevators(noElevators);
                }
                //Setting number of iterations
                if(line.startsWith("run_simulation")){
                    int noSimulation = Integer.parseInt(line.split(" ")[NUMBER_OF_SIMULATIONS_INDEX].trim());
                    settings.setNoSimulation(noSimulation);
                }
            }  
        //} Bracket for loop
    }
}
