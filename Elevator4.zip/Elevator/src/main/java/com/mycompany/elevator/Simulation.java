package com.mycompany.Elevator;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;

public class Simulation {
    private static final int MAXIMUM_POSSIBLE_FLOORS = 164;
    private static final int MINIMUM_NUMBER_FLOORS = 10;
    private static final int MAXIMUM_POSSIBLE_ELEVATORS = 74;
    private static final int MINIMUM_NUMBER_ELEVATORS = 8;
    private static final int MAXIMUM_NUMBER_SIMULATIONS = 74;
    private static final int MINIMUM_NUMBER_SIMULATIONS = 10;
    private static final int TOTAL_DIFFERENT_TYPES = 4;
    private ArrayList<Elevator> elevators;
    private ArrayList<Passenger> passengers;
    Random random = new Random();
    SimulatorSettings simSettings = new SimulatorSettings();
    Elevator elevator;
    Passenger passenger;
    
    public void InitSimulation() throws FileNotFoundException{
        // Create a new instance of ReadAndStore and use it to read the input file
        ReadAndStore reader = new ReadAndStore();
        reader.ReadFromFile();

        // Create a new instance of Building using the data stored in ReadAndStore
        Building building = new Building();

        // Run the simulation for a certain number of iterations
        int numIterations = 100;
        for (int i = 0; i < numIterations; i++) {
            building.update();
    }
    }
    
    public void Sim(){
        elevators = new ArrayList<>();
        passengers = new ArrayList<>();
        Building building = new Building();
        simSettings.setNoFloors(random.nextInt(MINIMUM_NUMBER_FLOORS, MAXIMUM_POSSIBLE_FLOORS));
        simSettings.setNoSimulation(random.nextInt(MINIMUM_NUMBER_ELEVATORS, MAXIMUM_POSSIBLE_ELEVATORS));
        simSettings.setNoElevators(random.nextInt(MINIMUM_NUMBER_SIMULATIONS, MAXIMUM_NUMBER_SIMULATIONS));
        
        int numFloors = simSettings.getNoFloors();
        int numElevators = simSettings.getNoElevators();
        int numSim = simSettings.getNoSimulation();
        int typeChance = TOTAL_DIFFERENT_TYPES;
        
        building.addSimElevator(typeChance, numElevators);
        building.addSimPassenger(typeChance, numSim);
        building.requestElevator(passenger);
        building.runElevators(numFloors);
        
    }
}


