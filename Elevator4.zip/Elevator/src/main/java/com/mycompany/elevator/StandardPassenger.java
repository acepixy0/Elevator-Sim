package com.mycompany.Elevator;

import java.util.Random;

public class StandardPassenger extends Passenger {
    Random random = new Random();
    //Default
    public StandardPassenger() {
        this.setRequestPriority(70);
    }
    StandardPassenger(int genRequestPercentage) {
        this.setGenRequestPriority(genRequestPercentage);
    }
    // Pass parametric data to arrayList
    public StandardPassenger(int startFloor,int endFloor){
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(random.nextInt(1, 30 + 1));
       this.setGenRequestPriority(random.nextInt(1, 70 + 1));
    }
    //Used to store info from file read
    StandardPassenger(int startFloor, int endFloor, int requestPriority) {
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
    }
    //Copy
    StandardPassenger(StandardPassenger standardP){
        
    }
    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
