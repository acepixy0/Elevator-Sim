package com.mycompany.Elevator;
import java.util.List;

/**
 *
 * @author Nathan J. Hagood
 */
public class TrackTime {
    private long startTime;
    private long currentTime;
    private long elapsedTime;
    private long interval;
    private List<Elevator> elevators;
    private List<Passenger> passengers;
    
    public TrackTime (long interval, List<Elevator> elevators, List<Passenger> passengers) {
        this.interval = interval;
        this.elevators = elevators;
        this.passengers = passengers;
    }
    
    public void startTimer() {
        startTime = System.currentTimeMillis();
        currentTime = startTime;
        
        while (true) {
            elapsedTime = System.currentTimeMillis() - currentTime;
            if (elapsedTime >= interval) {
                currentTime += elapsedTime;
                updateElevators();
                updatePassengers();
            }
        }
    }
    private void updateElevators() {
        for (Elevator elevator : elevators) {
            elevator.move();
        }
    }
    private void updatePassengers() {
        for (Passenger passenger : passengers) {
            passenger.updateStatus();
        }
    }
}

