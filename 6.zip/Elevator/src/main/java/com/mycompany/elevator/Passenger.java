package com.mycompany.Elevator;
public abstract class Passenger{

    private static int passengerCounter = 0;
    private int passengerID = 0;
    private int startFloor = 1;
    private int endFloor = 0;
    private int requestPriority = 0;
    private int genRequestPriority = 0;
    private boolean isInElevator = false;
    private boolean hasReachedDestination = false;
    
    public Passenger(){
        this.passengerID += passengerCounter++;
        
    }
    public int getRequestPriority() {
        return requestPriority;
    }
    public void setRequestPriority(int requestPriority) {
        this.requestPriority = requestPriority;
    }
     public int getGenRequestPriority() {
        return genRequestPriority;
    }
    public void setGenRequestPriority(int genRequestPriority) {
        this.genRequestPriority = genRequestPriority;
    }
    public static int getPassengerCounter() {
        return passengerCounter;
    }
    public int getPassengerID() {
        return passengerID;
    }
    public void setPassengerID(int passengerID) {
        this.passengerID = passengerID;
    }
    public int getStartFloor() {
        return startFloor;
    }
    public void setStartFloor(int startFloor) {
        this.startFloor = startFloor;
    }
    public int getEndFloor() {
        return endFloor;
    }
    public void setEndFloor(int endFloor) {
        this.endFloor = endFloor;
    }
    public boolean isInElevator() {
        return isInElevator;
    }
    public void setInElevator(boolean inElevator) {
        isInElevator = inElevator;
    }
    public boolean hasReachedDestination() {
        return hasReachedDestination;
    }
    public void setHasReachedDestination(boolean hasReachedDestination) {
        this.hasReachedDestination = hasReachedDestination;
    }
    
    public abstract boolean requestElevator(SimulatorSettings settings);

   
}
