package com.mycompany.Elevator;

import java.util.Random;

public class StandardElevator extends Elevator{
    private static int idCounter = 0;
    Random random = new Random();
    
    StandardElevator(int genServicePercentage) {
        this.setGenServicePriority(genServicePercentage);
    }
    // Pass parametric data to arrayList from file
    StandardElevator(int maxCapacity, int servicePriority) {
        super();
        this.setId(++idCounter);
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    // Random generated elevator
    StandardElevator() {
        super();
        this.setId(++idCounter);
        this.setGenServicePriority(random.nextInt(1, 70 + 1));
        this.setServicePriority(random.nextInt(1, 40 + 1));
        this.setMaxCapacity(random.nextInt(2, 10 + 1));
        this.getId();
    }
    StandardElevator(StandardElevator standardE){
        
    }
}
