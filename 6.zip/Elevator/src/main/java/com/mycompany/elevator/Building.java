package com.mycompany.Elevator;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Building{
    SimulatorSettings simSettings = new SimulatorSettings();
    SimulatorSettings settings = new SimulatorSettings("settings.txt");
    private ArrayList<Elevator> BElevators;
    private ArrayList<Passenger> BPassengers;
    Random random = new Random();
    Elevator elevator;
    Passenger passenger;
    
    public Building(){   
    }
    //Elevators from file
    public void addFileElevator(ArrayList<Elevator> elevatorList){
        //Add elevators from settings.txt
        BElevators.addAll(elevatorList);
    }//Passengers from file
    public void addFilePassenger(ArrayList<Passenger> passengerList) {
        //Add passengers from settings.txt
        BPassengers.addAll(passengerList);
    }
    //Generate simulated Elevators
    public void addSimElevator(int elevatorType, int numElevators){
        this.BElevators = new ArrayList<>();        
        // Create elevators and add to list
        for (int i = 0; i < numElevators; i++) {
            elevatorType = random.nextInt(elevatorType) + 1;
            switch (elevatorType){
                case 1:
                    elevator = new StandardElevator();
                    break;
                case 2:
                    elevator = new ExpressElevator();
                    break;
                case 3:
                    elevator = new FreightElevator();
                    break;
                case 4:
                    elevator = new GlassElevator();
                    break;
                default:
                    throw new RuntimeException("Invalid elevator type");
            }
            BElevators.add(elevator);
        }
    }
    //Generate simulated passengers
    public void addSimPassenger(int passengerType, int numSim, int numFloors) {
        this.BPassengers = new ArrayList<>();
        for(int i = 0; i < numSim; i++){
            passengerType = random.nextInt(passengerType) + 1;
            int startFloor = random.nextInt(numFloors + 1);
            int endFloor = random.nextInt(numFloors + 1);
            switch (passengerType){
                case 1:
                    passenger = new StandardPassenger(startFloor, endFloor);
                    break;
                case 2:
                    passenger = new VipPassenger(startFloor, endFloor);
                    break;
                case 3:
                    passenger = new FreightPassenger(startFloor, endFloor);
                    break;
                case 4:
                    passenger = new GlassPassenger(startFloor, endFloor);
                    break;
                default:
                    throw new RuntimeException("Invalid passenger type");
            }
            BPassengers.add(passenger);
        }
    }
    
    public List<Elevator> getElevators() {
    return BElevators;
    }
    public List<Passenger> getPassengers() {
    return BPassengers;
    } 
    
    public Elevator requestElevator(Passenger passenger) {
        int maxPriority = 0;
        Elevator selectedElevator = null;
        //Creating priority for each passenger
        for (Elevator elevator : BElevators) {
            if (elevator.isAvailable()) {
                int priority = (passenger.getRequestPriority() * elevator.getServicePriority()) + (passenger.getGenRequestPriority() * elevator.getGenServicePriority());
                if (priority > maxPriority) {
                    maxPriority = priority;
                    selectedElevator = elevator;
                }
            }
        }
        return selectedElevator;
    }

    public void runElevators(int numFloors) {
        int totalNumPassengers = BPassengers.size();
        int totalNumElevators = BElevators.size();
        int maxIterations = totalNumPassengers * totalNumElevators * numFloors;
        int iterations = 0;

        // Create a list to hold waiting passengers
        List<Passenger> waitingPassengers = new ArrayList<>(BPassengers);

        // Run the elevator system until all passengers are transported
        while (iterations < 10000) {
            boolean isAnyElevatorMoving = false;
            // Loop through each elevator
            for (Elevator elevator : BElevators) {
                
                if (!elevator.isMoving()) {
                    isAnyElevatorMoving = true;
                    elevator.setAvailable(true);
                    
                    // Pick up any waiting passengers on the current floor
                    List<Passenger> passengersToRemove = new ArrayList<>();
                    for (Passenger passenger : waitingPassengers) {
                        if (elevator.isAvailable() && passenger.getStartFloor() == elevator.getCurrentFloor()) {
                            elevator.stop();
                            elevator.openDoor();
                            elevator.addPassenger(passenger);
                            passengersToRemove.add(passenger);
                            System.out.println("Added Passenger");
                            elevator.toString();
                            
                        }
                    }
                    waitingPassengers.removeAll(passengersToRemove);

                    // Drop off any passengers who have reached their destination
                    List<Passenger> passengersInElevator = new ArrayList<>(elevator.getPassengers());
                    for (Passenger passenger : passengersInElevator) {
                        if (passenger.getEndFloor() == elevator.getCurrentFloor()) {
                            elevator.removePassenger(passenger);
                            System.out.println("Removed Passenger");
                            elevator.toString();
                        }
                    }
                    elevator.move();

                    // Open and close the elevator doors
                    if (!elevator.isMoving()) {
                        elevator.openDoor();
                        elevator.closeDoor();
                    }
                }
            }

        // Check if any elevator is still moving
        if (!isAnyElevatorMoving) {
            break;
        }
        iterations++;
    }
    }
}
