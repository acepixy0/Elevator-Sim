package com.mycompany.Elevator;

import java.util.Random;

public class FreightElevator extends Elevator{
    Random random = new Random();
    private static int idCounter;
    
    FreightElevator(int genServicePercentage) {
        this.setGenServicePriority(genServicePercentage);
    }
    
    // Pass parametric data to arrayList
    FreightElevator(int maxCapacity, int servicePriority) {
        super();
        this.setId(++idCounter);
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    FreightElevator(){
        super();
        this.setId(++idCounter);
        this.setGenServicePriority(random.nextInt(1, 5 + 1));
        this.setServicePriority(random.nextInt(1, 20 + 1));
        this.setMaxCapacity(random.nextInt(2, 15 + 1));
    }
    FreightElevator(FreightElevator freightE){
        
    }
}
