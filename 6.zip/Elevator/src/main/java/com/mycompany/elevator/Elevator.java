package com.mycompany.Elevator;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Elevator {
    private static int elevatorCounter = 0; // Number of elevator calls
    private int elevatorType = 0; // Numerical order: Standard, Express, Freight, Glass
    private int servicePriority = 0;
    private int genServicePriority = 0;// Percentage of passenger requests for each elevator type
    private int maxCapacity = 0; // Maximum amount of people allowed on elevator
    private int currentNumPass = 0; //Number of passengers at any given time
    private int currentFloor = 1;
    private int id = 0;
    String direction;
    private boolean isDoorOpen;
    private boolean isMoving;
    private boolean isStopped;
    private boolean isAvaliable;
    private boolean isAvailable = false;
    private ArrayList<Passenger> passengers;
    private List<Integer> visitNextFloor;
    
    Elevator(){
        passengers = new ArrayList<>();
        visitNextFloor = new ArrayList<>();    
    }
    public void setCurrentFloor(int floor) {
        this.currentFloor = floor;
    }
     public int getCurrentFloor() {
        return currentFloor;
    }//Checks for elevator avaliability
     public boolean isAvailable() {
        return !isMoving() && getCurrentNumPass() < getMaxCapacity();
    }
     public void setAvailable(boolean available) {
        isAvailable = available;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public static int getElevatorCounter() {
        return elevatorCounter;
    }
    public int getElevatorType() {
        return elevatorType;
    }
    public void setElevatorType(int elevatorType) {
        this.elevatorType = elevatorType;
    }
    public int getServicePriority() {
        return servicePriority;
    }
    public void setServicePriority(int servicePriority) {
        this.servicePriority = servicePriority;
    }
    public int getGenServicePriority() {
        return genServicePriority;
    }
    public void setGenServicePriority(int genServicePriority) {
        this.genServicePriority = genServicePriority;
    }
    public int getMaxCapacity() {
        return maxCapacity;
    }
    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }
    public int getCurrentNumPass() {
        return currentNumPass;
    }
    public void setCurrentNumPass(int currentNumPass) {
        this.currentNumPass = currentNumPass;
    }//Return Array of floors needed to be visited
    public List<Integer> getVisitNextFloor() {
        return visitNextFloor;
    }
    
    public boolean isMoving() {
        return isMoving;
    }
    //Add passengers to an internal arrayList
    public boolean addPassenger(Passenger passenger) {
        if (currentNumPass < maxCapacity){
            passengers.add(passenger);
            currentNumPass++;
            getVisitNextFloor().add(passenger.getStartFloor());
            getVisitNextFloor().add(passenger.getEndFloor());
            return true;
        }
        else{
            System.out.println("Not enough space....");
            return false;
        }
    }
    //Remove passengers to an internal arrayList
    public void removePassenger(Passenger passenger) {
        if(currentFloor == getVisitNextFloor().get(passenger.getEndFloor())){
            System.out.println("Here is your stop.");
            passengers.remove(passenger);
            currentNumPass--;
        }
    }// Return array
    public ArrayList<Passenger> getPassengers() {
        return this.passengers;
    }
    // Finds the closest floor via direction
    public int findClosestFloor(String direction) {
        int closestFloor = -1;
        int closestDistance = Integer.MAX_VALUE;
        for (int floor : visitNextFloor) {
            if ((direction.equals("up") && floor > currentFloor) || (direction.equals("down") && floor < currentFloor)) {
                int distance = Math.abs(currentFloor - floor);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closestFloor = floor;
                }
            }
        }
        return closestFloor;
    }
    // Moves elevator and finds the next floor
    public void move(){
        if (!isDoorOpen && !isMoving) {
            System.out.println("Elevator " + this.getId()+ " is moving.");
            isMoving = true;
            isStopped = false; 
            isAvaliable = false;
        }
        if (!getVisitNextFloor().isEmpty()) {
        int closestFloor;
        String direction;
        if (getCurrentFloor() < findClosestFloor("up")) {
            closestFloor = findClosestFloor("up");
            direction = "up";
        } else if (getCurrentFloor() > findClosestFloor("down")) {
            closestFloor = findClosestFloor("down");
            direction = "down";
        } else {
            closestFloor = findClosestFloor("up");
            direction = "up";
        }
        // go to the closest floor in the specified direction
        setCurrentFloor(closestFloor);
        System.out.println("Elevator " + this.getId() + " is going " + direction + " to floor " + closestFloor);
    }
    }
    //Stops elevators
    public void stop() {
        if (isMoving) {
            System.out.println("Elevator " + this.getId() + " has stopped.");
            isMoving = false;
            isStopped = true;
            isAvaliable = true;
        }
    }
    //Opens elevator
    public void openDoor() {
        if (!isDoorOpen && !isMoving && isStopped) {
            System.out.println("Elevator " + this.getId() + " doors are open.");
            isMoving = false;
            isStopped = true;
            isDoorOpen = true;
            isAvaliable = true;
        }
    }
    //Closes elevator
    public void closeDoor() {
        if (isDoorOpen && !isMoving && isAvaliable) {
            System.out.println("Elevator " + this.getId() + " doors are closed.");
            isMoving = false;
            isStopped = true;
            isDoorOpen = false;
            isAvaliable = false;
        }
    }  
    
    @Override
    public String toString() {
        return "Elevator " + id + " [Current Floor=" + currentFloor + ", Capacity=" + currentNumPass + ", Available=" + isAvailable + "]";
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Elevator)) return false;
        Elevator elevator = (Elevator) o;
        return id == elevator.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}


    
    
   