package com.mycompany.Elevator;
public class SimulatorSettings {
    private int noFloors = 0;
    private int noElevators = 0;
    private int noSimulation = 0;
    private int currentFloor = 0; 

    SimulatorSettings() {
        this.noFloors = noFloors;
        this.noElevators = noElevators;
        this.currentFloor = currentFloor;
        this.noSimulation = noSimulation;
    }
    
    SimulatorSettings(String file){
        
    }
    
    public int getNoFloors() {
        return noFloors;
    }

    public void setNoFloors(int noFloors) {
        this.noFloors = noFloors;
    }
    public int getNoElevators() {
        return noElevators;
    }
    public void setNoElevators(int noElevators) {
        this.noElevators = noElevators;
    }
    public int getNoSimulation() {
        return noSimulation;
    }
    public void setNoSimulation(int noSimulation) {
        this.noSimulation = noSimulation;
    }
    public int getCurrentFloor() {
        return currentFloor;
    }
    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }
}
