package com.mycompany.Elevator;
import java.io.FileNotFoundException;


public class Main {
    // Run Simulation
    public static void main(String[] args) throws FileNotFoundException {
        Simulation test = new Simulation();
        System.out.println("Simulation will now start.");
        test.Sim();
        //test.InitSimulation();
        System.out.println("Simulation ended.");
    }
    
}
