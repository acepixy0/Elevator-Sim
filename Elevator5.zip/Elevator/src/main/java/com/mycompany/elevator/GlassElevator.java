package com.mycompany.Elevator;

import java.util.Random;

public class GlassElevator extends Elevator{
    Random random = new Random();
    private static int idCounter;
    
    GlassElevator(int genServicePercentage) {
        this.setGenServicePriority(genServicePercentage);
    }
    
// Pass parametric data to arrayList
    GlassElevator(int maxCapacity, int servicePriority) {
        super();
        this.setId(++idCounter);
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    
    GlassElevator(){
        super();
        this.setId(++idCounter);
        this.setGenServicePriority(random.nextInt(1, 5 + 1));
        this.setServicePriority(random.nextInt(1, 15 + 1));
        this.setMaxCapacity(random.nextInt(2, 6 + 1));
    }
    GlassElevator(GlassElevator glassE){
        
    }
}
