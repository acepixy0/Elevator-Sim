package com.mycompany.Elevator;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;

public class Simulation {
    private static final int MAXIMUM_POSSIBLE_FLOORS = 164;
    private static final int MINIMUM_NUMBER_FLOORS = 10;
    private static final int MAXIMUM_POSSIBLE_ELEVATORS = 74;
    private static final int MINIMUM_NUMBER_ELEVATORS = 8;
    private static final int MAXIMUM_NUMBER_SIMULATIONS = 74;
    private static final int MINIMUM_NUMBER_SIMULATIONS = 10;
    private static final int TOTAL_DIFFERENT_TYPES = 4;
    private ArrayList<Elevator> elevators;
    private ArrayList<Passenger> passengers;
    Random random = new Random();
    SimulatorSettings simSettings = new SimulatorSettings();
    
    public void InitSimulation() throws FileNotFoundException{
        // Create a new instance of ReadAndStore and use it to read the input file in that class
        elevators = new ArrayList<>();
        passengers = new ArrayList<>();
        Building building = new Building();
        ReadAndStore reader = new ReadAndStore();
        reader.ReadFromFile();
        int elevatorType = 4;
        int numFloors = reader.settings.getNoFloors();
        int numSim = reader.settings.getNoSimulation();
        int numElevators = reader.settings.getNoElevators();
        
        building.addFileElevator(reader.elevators);
        building.addFilePassenger(reader.passengers);
        building.requestElevator(building.passenger);
        
        for (Passenger passenger : building.getPassengers()) {
            Elevator elevator = building.requestElevator(passenger);
            elevator.addPassenger(passenger);
        }
        building.runElevators(numFloors);
    }
    
    public void Sim(){
        Building buildingSim = new Building();
        ArrayList<Elevator> elevators = new ArrayList<>();
        ArrayList<Passenger> passengers = new ArrayList<>();
        
        simSettings.setNoFloors(random.nextInt(MINIMUM_NUMBER_FLOORS, MAXIMUM_POSSIBLE_FLOORS));
        simSettings.setNoSimulation(random.nextInt(MINIMUM_NUMBER_ELEVATORS, MAXIMUM_POSSIBLE_ELEVATORS));
        simSettings.setNoElevators(random.nextInt(MINIMUM_NUMBER_SIMULATIONS, MAXIMUM_NUMBER_SIMULATIONS));
        
        int numFloors = simSettings.getNoFloors();
        int numElevators = simSettings.getNoElevators();
        int numSim = simSettings.getNoSimulation();
        int typeChance = TOTAL_DIFFERENT_TYPES;
        
        buildingSim.addSimElevator(typeChance, numElevators);
        buildingSim.addSimPassenger(typeChance, numSim);
        passengers.addAll(buildingSim.getPassengers());
        
        for (Passenger passenger : buildingSim.getPassengers()) {
            Elevator elevator = new Elevator();
            elevator = buildingSim.requestElevator(passenger);
            elevator.addPassenger(passenger);  
        }
        buildingSim.runElevators(numFloors);
        
    }
}


