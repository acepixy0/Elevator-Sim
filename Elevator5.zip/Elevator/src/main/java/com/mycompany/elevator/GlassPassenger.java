package com.mycompany.Elevator;
import java.util.Random;

public class GlassPassenger extends Passenger {
    Random random = new Random();
    
    //Default
    GlassPassenger() {
    this.setRequestPriority(5);
    }
    GlassPassenger(int genRequestPercentage) {
        this.setGenRequestPriority(genRequestPercentage);
    }
    // Pass parametric data to arrayList
    GlassPassenger(int startFloor,int endFloor){
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(random.nextInt(1, 15 + 1));
       this.setGenRequestPriority(random.nextInt(1, 5 + 1));
    }
    //Used to store info from file read
    GlassPassenger(int startFloor, int endFloor, int requestPriority) {
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
    }
    GlassPassenger(GlassPassenger glassP){
        
    }
    
    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
