package com.mycompany.Elevator;

import java.util.Random;

public class ExpressElevator extends Elevator{
    Random random = new Random();
    private static int idCounter = 0;
    
    ExpressElevator(int genServicePercentage) {
        this.setGenServicePriority(genServicePercentage);
    }

    // Pass parametric data to arrayList
    ExpressElevator(int maxCapacity, int servicePriority) {
        super();
        this.setId(++idCounter);
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
    }
    ExpressElevator(){
        super();
        this.setId(++idCounter);
        this.setGenServicePriority(random.nextInt(1, 20 + 1));
        this.setServicePriority(random.nextInt(1, 25 + 1));
        this.setMaxCapacity(random.nextInt(2, 10 + 1));   
    }
    ExpressElevator(ExpressElevator expressE){
        
    }
}
