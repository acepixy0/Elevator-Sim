package com.mycompany.Elevator;
/**
 *
 * @author Nathan J. Hagood
 */
public abstract class Passenger{
    private static int passengerCounter = 0;
    private int passengerID = 0;
    private int startFloor = 1;
    private int endFloor = 0;
    private int requestPriority = 0;
    private int genRequestPriority = 0;
    private boolean hasReachedDestination = false;
    private Direction direction;
    private PassengerType type;
    
    public Passenger(){
    this.passengerID = ++passengerCounter;    
    this.direction = Direction.IDLE;
    }
    public enum Direction {
    UP,
    DOWN,
    IDLE
    }
    public enum PassengerType {
    STANDARD,
    FREIGHT,
    GLASS,
    VIP
    }
    public int getRequestPriority() {
        return requestPriority;
    }
    public void setRequestPriority(int requestPriority) {
        this.requestPriority = requestPriority;
    }
     public int getGenRequestPriority() {
        return genRequestPriority;
    }
    public void setGenRequestPriority(int genRequestPriority) {
        this.genRequestPriority = genRequestPriority;
    }
    public static int getPassengerCounter() {
        return passengerCounter;
    }
    public int getPassengerID() {
        return passengerID;
    }
    public void setPassengerID(int passengerID) {
        this.passengerID = passengerID;
    }
    public int getStartFloor() {
        return startFloor;
    }
    public void setStartFloor(int startFloor) {
        this.startFloor = startFloor;
    }
    public int getEndFloor() {
        return endFloor;
    }
    public void setEndFloor(int endFloor) {
        this.endFloor = endFloor;
    }
    public boolean hasReachedDestination() {
        return hasReachedDestination;
    }
    public void setHasReachedDestination(boolean hasReachedDestination) {
        this.hasReachedDestination = hasReachedDestination;
    }
    public Direction getDirection() {
        if (startFloor < endFloor) {
            return Direction.UP;
        } else if (startFloor > endFloor) {
            return Direction.DOWN;
        } else {
            // Passenger is already at their destination
            return null;
        }
    }
    public void setDirection(Direction direction) {
        this.direction = direction;
    }
    public PassengerType getType() {
        return type;
    }
    public void setType(PassengerType passengerType) {
        this.type = passengerType;
    }
    public String printType(){
        if (null == getType()) {
            return "UNKNOWN ";
        } 
        else switch (getType()) {
            case STANDARD:
                return "STANDARD Type ";
            case VIP:
                return "VIP Type ";
            case GLASS:
                return "GLASS Type ";
            case FREIGHT:
                return "FREIGHT Type ";
            default:
                return "UNKNOWN ";
        }
    }
    public abstract boolean requestElevator(SimulatorSettings settings);

    }
