package com.mycompany.Elevator;
import java.util.Objects;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class ExpressElevator extends Elevator{
    Random random = new Random();
    
    //Default
    ExpressElevator(){
    super();
    this.setType(ElevatorType.EXPRESS);
    }
    // Pass parametric data to arrayList from file
    ExpressElevator(int maxCapacity, int servicePriority, int GenServicePriority, int numOfFloors) {
        super();
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
        this.setGenServicePriority(GenServicePriority);
        this.setType(ElevatorType.EXPRESS);
        this.setNumFloors(numOfFloors);
    }
    // Random generated elevator
    ExpressElevator(int numFloors){
        super();
        this.setGenServicePriority(random.nextInt(1, 20 + 1));
        this.setServicePriority(random.nextInt(1, 25 + 1));
        this.setMaxCapacity(random.nextInt(2, 10 + 1));   
        this.setCurrentFloor(this.getCurrentFloor());
        this.setType(ElevatorType.EXPRESS);
        this.setCurrentFloor(random.nextInt(numFloors) + 1);
    }
    //Copy
    ExpressElevator(ExpressElevator expressE){
        
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
            if (!(o instanceof ExpressElevator)) return false;
                ExpressElevator elevator = (ExpressElevator) o;
                return getId() == elevator.getId();
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 61 * hash + Objects.hashCode(this.random);
        return hash;
    }
}
