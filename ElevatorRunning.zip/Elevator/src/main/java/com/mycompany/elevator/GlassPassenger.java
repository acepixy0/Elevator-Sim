package com.mycompany.Elevator;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class GlassPassenger extends Passenger {
    Random random = new Random();
    
    //Default
    GlassPassenger() {
        super();
        this.setType(PassengerType.GLASS);
    }
    // Pass parametric data to arrayList
    GlassPassenger(int startFloor,int endFloor){
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(random.nextInt(1, 15 + 1));
       this.setGenRequestPriority(random.nextInt(1, 5 + 1));
       this.setType(PassengerType.GLASS);
    }
    //Used to store info from file read
    GlassPassenger(int startFloor, int endFloor, int requestPriority, int genRequestPercentage) {
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
       this.setGenRequestPriority(genRequestPercentage);
       this.setType(PassengerType.GLASS);
    }
    //Copy
    GlassPassenger(GlassPassenger glassP){
        
    }
    
    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        System.out.println("Glass Passenger request an elevator");
        return true;
    }
    
}
