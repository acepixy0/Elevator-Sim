package com.mycompany.Elevator;
import java.util.Objects;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class StandardElevator extends Elevator{
    
    Random random = new Random();
    
    StandardElevator(){
        super();
        this.setType(ElevatorType.STANDARD);
    }
    // Pass parametric data to arrayList from file
    StandardElevator(int maxCapacity, int servicePriority, int GenServicePriority,int numOfFloors) {
        super();
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
        this.setGenServicePriority(GenServicePriority);
        this.setType(ElevatorType.STANDARD);
        this.setNumFloors(numOfFloors);
    }
    // Random generated elevator
    StandardElevator(int numFloors) { 
        super();
        this.setGenServicePriority(random.nextInt(1, 70 + 1));
        this.setServicePriority(random.nextInt(1, 40 + 1));
        this.setMaxCapacity(random.nextInt(2, 10 + 1));
        this.setType(ElevatorType.STANDARD);
        this.setCurrentFloor(random.nextInt(numFloors) + 1);
    }
    //Copy
    StandardElevator(StandardElevator standardE){
        
    }
    @Override
public boolean equals(Object o) {
        if (this == o) return true;
            if (!(o instanceof StandardElevator)) return false;
                StandardElevator elevator = (StandardElevator) o;
                return getId() == elevator.getId();
}

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 31 * hash + Objects.hashCode(this.random);
        return hash;
    }
}
