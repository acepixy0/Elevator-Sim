package com.mycompany.Elevator;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class VipPassenger extends Passenger {
    Random random = new Random();
    
    //Default
    VipPassenger() {
        super();
        this.setType(PassengerType.VIP);
    }
    // Pass parametric data to arrayList
    VipPassenger(int startFloor,int endFloor){
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(random.nextInt(1, 10 + 1));
       this.setGenRequestPriority(random.nextInt(1, 10 + 1));
       this.setType(PassengerType.VIP);
    }
    //Used to store info from file read
    VipPassenger(int startFloor, int endFloor, int requestPriority, int genRequestPercentage) {
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
       this.setGenRequestPriority(genRequestPercentage);
       this.setType(PassengerType.VIP);
    }
    //Copy
    VipPassenger(VipPassenger vipP){
        
    }

    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        System.out.println("VIP Passenger request an elevator");
        return true;
    }
    
}

