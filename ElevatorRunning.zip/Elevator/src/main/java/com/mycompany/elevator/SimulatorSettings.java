package com.mycompany.Elevator;
/**
 *
 * @author Nathan J. Hagood
 */
public class SimulatorSettings {
    private int noFloors;
    private int noElevators;
    private int noSimulation;
    private int currentFloor;

    SimulatorSettings() {
        this(0, 0, 0, 0);
    }

    SimulatorSettings(String file) {
        this(0, 0, 0, 0);
        // read values from file and update the instance variables
    }

    SimulatorSettings(int noFloors, int noElevators, int currentFloor, int noSimulation) {
        this.noFloors = noFloors;
        this.noElevators = noElevators;
        this.currentFloor = currentFloor;
        this.noSimulation = noSimulation;
    }
    
    public int getNoFloors() {
        return noFloors;
    }

    public void setNoFloors(int noFloors) {
        this.noFloors = noFloors;
    }
    public int getNoElevators() {
        return noElevators;
    }
    public void setNoElevators(int noElevators) {
        this.noElevators = noElevators;
    }
    public int getNoSimulation() {
        return noSimulation;
    }
    public void setNoSimulation(int noSimulation) {
        this.noSimulation = noSimulation;
    }
    public int getCurrentFloor() {
        return currentFloor;
    }
    public void setCurrentFloor(int currentFloor) {
        this.currentFloor = currentFloor;
    }
}
