package com.mycompany.Elevator;
import java.io.FileNotFoundException;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class Simulation {
    private static final int MAXIMUM_POSSIBLE_FLOORS = 164;
    private static final int MINIMUM_NUMBER_FLOORS = 10;
    private static final int MAXIMUM_POSSIBLE_ELEVATORS = 74;
    private static final int MINIMUM_NUMBER_ELEVATORS = 8;
    private static final int MAXIMUM_NUMBER_SIMULATIONS = 74;
    private static final int MINIMUM_NUMBER_SIMULATIONS = 10;
    private static final int TOTAL_DIFFERENT_TYPES = 4;
    Random random = new Random();
    SimulatorSettings simSettings = new SimulatorSettings();
    
    public void InitSimulation() throws FileNotFoundException{
        // Create a new instance of ReadAndStore and use it to read the input file in that class
        Building building = new Building();
        ReadAndStore reader = new ReadAndStore();
        reader.ReadFromFile();
        building.addFileElevator(reader.getElevatorInfo(), reader.getFileNumElevators());
        building.addFilePassenger(reader.getPassengerInfo(), reader.getFileNumSimulations());
        
        building.runElevators();
    }
    
    public void Sim(){
        //Create a new random simulation
        Building buildingSim = new Building();
        
        simSettings.setNoFloors(random.nextInt(MINIMUM_NUMBER_FLOORS, MAXIMUM_POSSIBLE_FLOORS));
        simSettings.setNoSimulation(random.nextInt(MINIMUM_NUMBER_ELEVATORS, MAXIMUM_POSSIBLE_ELEVATORS));
        simSettings.setNoElevators(random.nextInt(MINIMUM_NUMBER_SIMULATIONS, MAXIMUM_NUMBER_SIMULATIONS));
        
        int numFloors = simSettings.getNoFloors();
        int numElevators = simSettings.getNoElevators();
        int numSim = simSettings.getNoSimulation();
        int typeChance = TOTAL_DIFFERENT_TYPES;
        
        buildingSim.addSimElevator(typeChance, numElevators, numFloors);
        buildingSim.addSimPassenger(typeChance, numSim, numFloors);
        
        buildingSim.runElevators();
        
    }
}


