package com.mycompany.Elevator;
import com.mycompany.Elevator.Passenger.PassengerType;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
/**
 *
 * @author Nathan J. Hagood
 */
public class Elevator {
    private static int idCounter = 0;
    private static int elevatorCounter = 0; // Number of elevator calls
    private int servicePriority = 0;
    private int genServicePriority = 0;// Percentage of passenger requests for each elevator type
    private int maxCapacity = 0; // Maximum amount of people allowed on elevator
    private int currentNumPass = 0; //Number of passengers at any given time
    private int currentFloor = 1;
    private int id = 0;
    private int numFloors;
    private boolean isMoving;
    private ArrayList<Passenger> passengers;
    private List<Integer> visitNextFloor;
    private Direction direction;
    private ElevatorType type;
    
    
    
    Elevator(){
        passengers = new ArrayList<>();
        visitNextFloor = new ArrayList<>(); 
        currentFloor = 1;
        this.direction = Direction.IDLE;
        this.numFloors = 0;
        this.id = ++idCounter;
    }
    public enum ElevatorType {
    STANDARD(PassengerType.STANDARD),
    EXPRESS(PassengerType.VIP),
    GLASS(PassengerType.GLASS),
    FREIGHT(PassengerType.FREIGHT);

    private PassengerType passengerType;

        private ElevatorType(PassengerType passengerType) {
            this.passengerType = passengerType;
        }

        public PassengerType getPassengerType() {
            return passengerType;
        }
    }
    public enum Direction {
    UP,
    DOWN,
    IDLE
    }
    public void setNumFloors(int num){
        this.numFloors = num;
    }
    public int getNumFloors(){
        return numFloors;
    }
    public void setCurrentFloor(int floor) {
        this.currentFloor = floor;
    }
     public int getCurrentFloor() {
        return currentFloor;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public static int getElevatorCounter() {
        return elevatorCounter;
    }
    public ElevatorType getType() {
        return type;
    }
    public void setType(ElevatorType elevatorType) {
        this.type = elevatorType;
    }
    public int getServicePriority() {
        return servicePriority;
    }
    public void setServicePriority(int servicePriority) {
        this.servicePriority = servicePriority;
    }
    public int getGenServicePriority() {
        return genServicePriority;
    }
    public void setGenServicePriority(int genServicePriority) {
        this.genServicePriority = genServicePriority;
    }
    public int getMaxCapacity() {
        return maxCapacity;
    }
    public void setMaxCapacity(int maxCapacity) {
        this.maxCapacity = maxCapacity;
    }
    public int getCurrentNumPass() {
        return currentNumPass;
    }
    public void setCurrentNumPass(int currentNumPass) {
        this.currentNumPass = currentNumPass;
    }
    //Return Array of floors needed to be visited
    public List<Integer> getVisitNextFloor() {
        return visitNextFloor;
    }
    //Add passengers to an internal arrayList
    public boolean addPassenger(Passenger passenger) {
        if (currentNumPass < maxCapacity){
            passengers.add(passenger);
            currentNumPass++;
            getVisitNextFloor().add(passenger.getStartFloor());
            getVisitNextFloor().add(passenger.getEndFloor());
            return true;
        }
        else{
            if(currentNumPass == maxCapacity){
                System.out.println("Not enough space....");
            }
            return false;
        }
    }
    //Remove passengers to an internal arrayList
    public void removePassenger(Passenger passenger) {
            passengers.remove(passenger);
            currentNumPass--;
        
    }// Return array
    public ArrayList<Passenger> getPassengers() {
        return this.passengers;
    }
    
    public Direction getDirection() {
        return direction;
    }
    public void setDirection(Direction direction){
        this.direction = direction;
    }
    public boolean isMoving() {
        return isMoving;
    }
    public void moveUp() {
        if(currentFloor < numFloors){
            currentFloor++;
            direction = Direction.UP;
        } 
        else{
            direction = Direction.DOWN;
        }
    }
    public void moveDown(){
        if(currentFloor > 1){
            currentFloor--;
            direction = Direction.DOWN;
        } 
        else{
            direction = Direction.UP;
        }
    }
    public void checkIdle() {
        if (getCurrentFloor() == 1 && getDirection() == Direction.DOWN) {
            setDirection(Direction.IDLE);
            System.out.println("Elevator " + getId() + " is now idle.");
        } 
        else if (getCurrentFloor() == getNumFloors() && getDirection() == Direction.UP) {
            setDirection(Direction.IDLE);
            System.out.println("Elevator " + getId() + " is now idle.");
        } 
        else if (getPassengers().isEmpty() && getDirection() != Direction.IDLE) {
            setDirection(Direction.IDLE);
            System.out.println("Elevator " + getId() + " is now idle.");
        }
    }
    public String printDirection(){
        if (null == getDirection()) {
            return "UNKNOWN";
        } 
        else switch (getDirection()) {
            case IDLE:
                return "IDLE";
            case UP:
                return "UP";
            case DOWN:
                return "DOWN";
            default:
                return "UNKNOWN";
        }
    }
    public String printType(){
        if (null == getType()) {
            return "UNKNOWN";
        } 
        else switch (getType()) {
            case STANDARD:
                return "STANDARD Type ";
            case EXPRESS:
                return "EXPRESS Type ";
            case GLASS:
                return "GLASS Type ";
            case FREIGHT:
                return "FREIGHT Type ";
            default:
                return "UNKNOWN";
        }
    }
     
    @Override
    public String toString() {
        return printType() + "Elevator # " + id + " Status: [Current Floor = " + currentFloor + ", Capacity = " + currentNumPass + ", Direction = " + printDirection() + "]";
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Elevator)) return false;
        Elevator elevator = (Elevator) o;
        return id == elevator.id;
    }
    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
    
}


    
    
   