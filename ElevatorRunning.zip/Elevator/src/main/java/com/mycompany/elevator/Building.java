package com.mycompany.Elevator;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class Building{
    private ArrayList<Elevator> BElevators;
    private ArrayList<Passenger> BPassengers;
    private ArrayList<Passenger> unpickedPassengers;
    private ArrayList<Passenger> previousUnpickedPassengers;
    ArrayList<Passenger> allPassengers;
    Random random = new Random();
    Elevator elevator;
    Passenger passenger;
    private static final int MAX_RECURSION_DEPTH = 100;
    private int recursionDepth = 0;
    
    public Building(){   
        unpickedPassengers = new ArrayList<>();
        allPassengers = new ArrayList<>();
    }
    //Provide service to requesting passengers
    public void runElevators() { 
        System.out.println("Building a new set of Elevators");
        boolean allPassengersArrived = false;
        allPassengers = new ArrayList<>(BPassengers);
        assignPassengersToElevators(this.allPassengers);
        
        while(allPassengersArrived == false){
            assignWaitPassengersToElevators(this.unpickedPassengers);
            this.unpickedPassengers = previousUnpickedPassengers;
            if (elevator != null) {
                elevator.checkIdle();
            }
            // check if all waiting passengers have reached their destination floor
            allPassengersArrived = previousUnpickedPassengers.isEmpty() || allElevatorsIdle();
        
            if (allPassengersArrived == true) {
                System.out.println("All passengers have reached their destination floor. Stopping all elevators.");
                BPassengers.clear();
                previousUnpickedPassengers.clear();
                BElevators.clear();
                allPassengers.clear();
                unpickedPassengers.clear();
                break;
            }
            else{
                System.out.println("There is " + previousUnpickedPassengers.size() + "passengers that did not make it to their destination");
            }
        }
    }
    
    //Elevators from file
    public void addFileElevator(ArrayList<Elevator> elevatorList, int numElevators){
        //Add elevators from settings.txt
        this.BElevators = new ArrayList<>();
        elevatorList.removeIf(Objects::isNull);
        
        //Iterates until the size of elevators increases to the provided amount via copy
        for (int i = 0; elevatorList.size() < numElevators; i++) {
            elevatorList.add(elevatorList.get(i));
        }
        BElevators.addAll(elevatorList);
    }
    //Passengers from file
    public void addFilePassenger(ArrayList<Passenger> passengerList, int numSimulations) {
        //Add passengers from settings.txt
        this.BPassengers = new ArrayList<>();
        passengerList.removeIf(Objects::isNull);
        
        //Iterates over number of simulations (total passengers iterated over) and add additional passengers from the given list
        for (int i = 0; passengerList.size() < numSimulations; i++) {
            passengerList.add(passengerList.get(i));
        }
        BPassengers.addAll(passengerList);
    }
    
    //Generate simulated Elevators
    public void addSimElevator(int elevatorType, int numElevators, int numFloors){
        this.BElevators = new ArrayList<>();        
        // Create elevators and add to list
        for (int i = 0; i < numElevators; i++) {
            elevatorType = random.nextInt(elevatorType) + 1;
            switch (elevatorType){
                case 1 -> elevator = new StandardElevator(numFloors);
                case 2 -> elevator = new ExpressElevator(numFloors);
                case 3 -> elevator = new FreightElevator(numFloors);
                case 4 -> elevator = new GlassElevator(numFloors);
                default -> throw new RuntimeException("Invalid elevator type");
            }
            BElevators.add(elevator);
            elevator.setNumFloors(numFloors);
        }
    }
    //Generate simulated passengers
    public void addSimPassenger(int passengerType, int numSim, int numFloors) {
        this.BPassengers = new ArrayList<>();
        for(int i = 0; i < numSim; i++){
            passengerType = random.nextInt(passengerType) + 1;
            int startFloor = random.nextInt(numFloors + 1);
            int endFloor = random.nextInt(numFloors + 1);
            switch (passengerType){
                case 1 -> passenger = new StandardPassenger(startFloor, endFloor);
                case 2 -> passenger = new VipPassenger(startFloor, endFloor);
                case 3 -> passenger = new FreightPassenger(startFloor, endFloor);
                case 4 -> passenger = new GlassPassenger(startFloor, endFloor);
                default -> throw new RuntimeException("Invalid passenger type");
            }
            BPassengers.add(passenger);
        }
    }
    
    public List<Elevator> getElevators() {
    return BElevators;
    }
    public List<Passenger> getPassengers() {
    return BPassengers;
    }
    
    //Calculates which elevator is assigned to each passenger by distance and priority
    public Elevator getNearestElevator(int startFloor, Elevator.Direction direction, int pGenRequestPriority,int pRequestPriority) {
        Elevator nearestElevator = null;
        int minDistance = Integer.MAX_VALUE;
        for (Elevator elevator : BElevators) {
            if (elevator != null) {
                if (elevator.getDirection() == Elevator.Direction.IDLE || elevator.getDirection() == direction) {
                    int distance = Math.abs(elevator.getCurrentFloor() - startFloor);
                    int weightedDistance = distance * (elevator.getServicePriority() + elevator.getGenServicePriority() + pGenRequestPriority + pRequestPriority);
                    if (weightedDistance < minDistance) {
                        nearestElevator = elevator;
                        minDistance = weightedDistance;
                    }
                }
            }
        }
        return nearestElevator;
    }
    
    //Finds and adds passengers to elevators
    public void assignPassengersToElevators(ArrayList<Passenger> currentWaitingPassengers){
        for (Passenger passenger : currentWaitingPassengers) {
            if (passenger != null) {
                int startFloor = passenger.getStartFloor();
                int endFloor = passenger.getEndFloor();
                int genRequestPriority = passenger.getGenRequestPriority();
                int requestPriority = passenger.getRequestPriority();
                Elevator.Direction direction = (startFloor < endFloor) ? Elevator.Direction.UP : Elevator.Direction.DOWN;
                Elevator nearestElevator = getNearestElevator(startFloor, direction,genRequestPriority, requestPriority);
                if (nearestElevator != null) {
                    nearestElevator.setDirection(direction);
                    if (nearestElevator.getCurrentNumPass() < nearestElevator.getMaxCapacity()) {
                        nearestElevator.addPassenger(passenger);
                        System.out.println(passenger.printType() + "Passenger #" + passenger.getPassengerID() + " boarded " + nearestElevator.printType() + "Elevator #" + nearestElevator.getId());
                    }
                    else{
                        this.unpickedPassengers.add(passenger);
                        System.out.println(passenger.printType() + "Passenger #" + passenger.getPassengerID()+ " could not board " + nearestElevator.printType() + "Elevator #" + nearestElevator.getId() + " (Elevator is full or not on the same floor)");
                        moveElevators();
                        
                    }
                }
                else{
                    this.unpickedPassengers.add(passenger);
                    System.out.println(passenger.printType() + "Passenger #" + passenger.getPassengerID() + " could not board any elevator (No available elevators)");
                    moveElevators();
                }
            }
        }
        moveElevators();
        if (elevator != null) {
            elevator.checkIdle();
        }
    }
    //Recursion used to run until all passengers have made it to their destination
    public void assignWaitPassengersToElevators(ArrayList<Passenger> currentWaitingPassengers){
        if (recursionDepth >= MAX_RECURSION_DEPTH) {
            System.out.println("Reached maximum recursion depth, stopping elevators.");
            return;
        }
        recursionDepth++;
        
        // check if there are any passengers in the waiting list that can now board the elevator
        if(recursionDepth < MAX_RECURSION_DEPTH || !previousUnpickedPassengers.isEmpty()){
            previousUnpickedPassengers = new ArrayList<>();
            List<Passenger> toRemove = new ArrayList<>();
            previousUnpickedPassengers.addAll(currentWaitingPassengers);
            unpickedPassengers.clear();
        
            for (Passenger passenger : previousUnpickedPassengers) {
                int startFloor = passenger.getStartFloor();
                int endFloor = passenger.getEndFloor();
                int genRequestPriority = passenger.getGenRequestPriority();
                int requestPriority = passenger.getRequestPriority();
                Elevator.Direction direction = (startFloor < endFloor) ? Elevator.Direction.UP : Elevator.Direction.DOWN;
                Elevator nearestElevator = getNearestElevator(startFloor, direction,genRequestPriority, requestPriority);
    
                if (nearestElevator != null) {
                    if (nearestElevator.getCurrentNumPass() < nearestElevator.getMaxCapacity()) {
                        nearestElevator.addPassenger(passenger);
                        nearestElevator.setDirection(direction);
                        toRemove.add(passenger);
                        System.out.println(passenger.printType() + "Passenger #" + passenger.getPassengerID() + " boarded " + nearestElevator.printType() + "Elevator # " + nearestElevator.getId() + " from waiting list");
                    }
                    else{
                        System.out.println(passenger.printType() + "Passenger #" + passenger.getPassengerID()+ " could not board " + nearestElevator.printType() + "Elevator #" + nearestElevator.getId() + " (Elevator is full or not on the same floor)");
                        moveElevators();
                    }
                }
                else{
                    // If no nearest elevator is found, add the passenger back to the waiting list
                    System.out.println(passenger.printType() + "Passenger #" + passenger.getPassengerID() + " could not board any elevator (No available elevators)");
                    moveElevators();
                }
            }
            previousUnpickedPassengers.removeAll(toRemove);
            moveElevators();
            assignWaitPassengersToElevators(this.previousUnpickedPassengers);
            recursionDepth--;
        }
    }
    //Moves elevators up and down making sure to remove passengers
    public void moveElevators(){
        for (Elevator elevator : BElevators) {
            if (elevator != null) {
                System.out.println(elevator);
                if (elevator.getDirection() == Elevator.Direction.UP) {
                    elevator.moveUp();
                    System.out.println(elevator.printType() + "Elevator #" + elevator.getId() + " moved up to floor " + elevator.getCurrentFloor());
                
                    // check if elevator has reached the top floor and there are still passengers that need to go down
                    if (elevator.getCurrentFloor() == elevator.getNumFloors() && elevator.getCurrentNumPass() > 0) {
                    elevator.setDirection(Elevator.Direction.DOWN);
                    System.out.println(elevator.printType() + "Elevator #" + elevator.getId() + " changed direction to DOWN");
                    }
                } 
                else if (elevator.getDirection() == Elevator.Direction.DOWN) {
                    elevator.moveDown();
                    System.out.println(elevator.printType() + "Elevator #" + elevator.getId() + " moved down to floor " + elevator.getCurrentFloor());
                }
            
                ArrayList<Passenger> elevatorPassengers = new ArrayList<>(elevator.getPassengers());
                for (Passenger passenger : elevatorPassengers) {
                    if (passenger.getEndFloor() == elevator.getCurrentFloor()) {
                        elevator.removePassenger(passenger);
                        passenger.setHasReachedDestination(true);
                        System.out.println(passenger.printType() + "Passenger #" + passenger.getPassengerID() + " departed from " + elevator.printType() + "Elevator #" + elevator.getId() + " on floor " + elevator.getCurrentFloor());
                    }
                }
            }
        }
    }
    //Checks to see if all elevators are idle
    public boolean allElevatorsIdle() {
        for (Elevator elevator : BElevators) {
            if (elevator != null) {
                if (!elevator.getDirection().equals(Elevator.Direction.IDLE)) {
                    return false;
                }
            }
        }
        return true;
    }
}


