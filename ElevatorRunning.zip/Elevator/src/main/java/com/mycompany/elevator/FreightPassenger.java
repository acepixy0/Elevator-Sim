package com.mycompany.Elevator;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class FreightPassenger extends Passenger {
    Random random = new Random();
    
    //Default
    FreightPassenger() {
        super();
        this.setType(PassengerType.FREIGHT);
    }
    // Pass parametric data to arrayList
    FreightPassenger(int startFloor,int endFloor){
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(random.nextInt(1, 20 + 1));
       this.setGenRequestPriority(random.nextInt(1, 15 + 1));
       this.setType(PassengerType.FREIGHT);
    }
    //Used to store info from file read
    FreightPassenger(int startFloor, int endFloor, int requestPriority, int genRequestPercentage) {
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
       this.setGenRequestPriority(genRequestPercentage);
       this.setType(PassengerType.FREIGHT);
    }
    //Copy
    FreightPassenger(FreightPassenger freightP){
        
    }

    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        System.out.println("Freight Passenger request an elevator");
        return true;
    }
}