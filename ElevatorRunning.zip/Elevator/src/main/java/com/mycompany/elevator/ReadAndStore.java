package com.mycompany.Elevator;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
/**
 *
 * @author Nathan J. Hagood
 */
public class ReadAndStore {
    private static final int TYPE_INDEX = 1;
    private static final int ELEVATOR_TYPE_INDEX = 1;
    private static final int NUMBER_OF_FLOORS_INDEX = 1;
    private static final int MAX_CAPACITY_INDEX = 2;
    private static final int GENERAL_PERCENTAGE_INDEX = 2;
    private static final int NUMBER_OF_ELEVATORS_INDEX = 1;
    private static final int NUMBER_OF_SIMULATIONS_INDEX = 1;
    private static final int START_FLOOR_INDEX = 2;
    private static final int SERVICE_PRIORITY_INDEX = 3;
    private static final int END_FLOOR_INDEX = 3;
    private static final int PASSENGER_TYPE_INDEX = 4;
    private static final int REQUEST_PRIORITY_INDEX = 5;
    
    SimulatorSettings settings = new SimulatorSettings("settings.txt");
    ArrayList<Passenger> passengers = new ArrayList<>();;
    ArrayList<Elevator> elevators = new ArrayList<>(); ;
    Passenger passenger;
    Elevator elevator;
    File file = new File("C:\\Users\\Nathan J. Hagood\\Documents\\School Work\\Elevator\\src\\main\\java\\com\\mycompany\\elevator\\settings.txt");
    
    //Reads from file and stores values to be sent to Building Class
    public void ReadFromFile() throws FileNotFoundException{
        setFileNumFLoors();
        setFileNumSimulations();
        setFileNumElevators();
        setElevatorInfo();
        setPassengerInfo();
    }
    
    public void setFileNumElevators() throws FileNotFoundException{
        try (Scanner scanner = new Scanner(file)) {
            scanner.useDelimiter(" ");
            while(scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                //Setting number of elevators
                if(line.startsWith("number_of_elevators")){
                    int noElevators = Integer.parseInt(line.split(" ")[NUMBER_OF_ELEVATORS_INDEX].trim());
                    settings.setNoElevators(noElevators);
                }
            }
        }
    }
    public int getFileNumElevators(){
        return settings.getNoElevators();
    }
    
    public void setFileNumSimulations() throws FileNotFoundException{
        try (Scanner scanner = new Scanner(file)) {
            scanner.useDelimiter(" ");
            while(scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                //Setting number of iterations
                if(line.startsWith("run_simulation")){
                    int noSimulation = Integer.parseInt(line.split(" ")[NUMBER_OF_SIMULATIONS_INDEX].trim());
                    settings.setNoSimulation(noSimulation);
                }
            }
        }
    }
    public int getFileNumSimulations(){
        return settings.getNoSimulation();
    }
    
    public void setFileNumFLoors() throws FileNotFoundException{
        try (Scanner scanner = new Scanner(file)) {
            scanner.useDelimiter(" ");
            int stringToNum = 0;
            //While scanner can read a next line and implement arguments for ArrayList
            while(scanner.hasNextLine()){
                String line = scanner.nextLine().trim();
                System.out.println(line);
                //Determining number of floors
                if (line.startsWith("floors")){
                    String[] segment = line.split("\\s+");
                    // Chopping up data into sgments saved into an array
                    if (segment.length >= 2){ 
                        String numString = segment[NUMBER_OF_FLOORS_INDEX].trim();
                        try{
                            stringToNum = Integer.parseInt(numString);
                            System.out.println("Number of floors: " + stringToNum);
                            settings.setNoFloors(stringToNum);
                            System.out.println(settings.getNoFloors());
                        }
                        //Error out
                        catch(NumberFormatException e){
                            System.out.println("Invalid line format for number of floors: " + line);
                            break;
                        }
                    }
                }
            }
        }
    }
    
    public void setPassengerInfo() throws FileNotFoundException{
        try (Scanner scanner = new Scanner(file)) {
            this.passengers = new ArrayList<>();
            scanner.useDelimiter(" ");
            int startFloor = 0;
            int endFloor = 0;
            int requestPriority = 0;
            String passengerType = "";
            Map<String, Integer> percentages = getPassRequestPercent();
            int standardGenRequestPriority = percentages.get("Standard");
            int vipGenRequestPriority = percentages.get("VIP");
            int freightGenRequestPriority = percentages.get("Freight");
            int glassGenRequestPriority = percentages.get("Glass");
            
            //While scanner can read a next line and implement arguments for ArrayList
            while(scanner.hasNextLine()){
                String line = scanner.nextLine().trim();
                //Adding passenger type to arrayList
                if(line.startsWith("add_passenger")){
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 4) {
                        try {
                            startFloor = Integer.parseInt(segment[START_FLOOR_INDEX].trim());
                            endFloor = Integer.parseInt(segment[END_FLOOR_INDEX].trim());
                            requestPriority = Integer.parseInt(segment[REQUEST_PRIORITY_INDEX].trim());
                            passengerType = segment[PASSENGER_TYPE_INDEX].trim();
                        }
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for passenger details: " + line);
                            continue;
                        }
                        //Determine passenger type
                        switch (passengerType) {
                            case "Standard" -> passengers.add(new StandardPassenger(startFloor, endFloor, requestPriority, standardGenRequestPriority));
                            case "VIP" -> passengers.add(new VipPassenger(startFloor, endFloor, requestPriority, vipGenRequestPriority));
                            case "Freight" -> passengers.add(new FreightPassenger(startFloor, endFloor, requestPriority, freightGenRequestPriority));
                            case "Glass" -> passengers.add(new GlassPassenger(startFloor, endFloor, requestPriority, glassGenRequestPriority));
                            default -> {
                            }
                        }
                    }
                }
                passengers.add(passenger);
            }
        }
    }
    public Map<String, Integer> getPassRequestPercent() throws FileNotFoundException {
        Map<String, Integer> percentages;
        try (Scanner scanner = new Scanner(file)) {
            scanner.useDelimiter(" ");
            percentages = new HashMap<>();
            while(scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                if(line.startsWith("passenger_request_percentage")) {
                    String[] segment = line.split("\\s+");
                    if (segment.length >= 3) {
                        try {
                            String passengerType = segment[TYPE_INDEX].trim();
                            int genRequestPercentage = Integer.parseInt(segment[GENERAL_PERCENTAGE_INDEX].trim());
                            percentages.put(passengerType, genRequestPercentage);
                        }
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for passenger request percentage details: " + line);
                        }
                    }
                }
            }
        }
        return percentages;
    }
    public ArrayList<Passenger> getPassengerInfo(){
        return this.passengers;
    }
    
    public void setElevatorInfo() throws FileNotFoundException{
        try (Scanner scanner = new Scanner(file)) {
            this.elevators = new ArrayList<>();
            scanner.useDelimiter(" ");
            String elevatorType = "";
            int maxCapacity = 0;
            int servicePriority = 0;
            int numOfFloors = settings.getNoFloors();
            Map<String, Integer> percentages = getElevatorRequestPercent();
            int standardGenServicePriority = percentages.get("StandardElevator");
            int expressGenServicePriority = percentages.get("ExpressElevator");
            int freightGenServicePriority = percentages.get("FreightElevator");
            int glassGenServicePriority = percentages.get("GlassElevator");
            //While scanner can read a next line and implement arguments for ArrayList
            while(scanner.hasNextLine()){
                String line = scanner.nextLine().trim();
                //Adding elevator type to arrayList
                if(line.startsWith("elevator_type")){
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 4) {
                        try {
                            elevatorType = segment[ELEVATOR_TYPE_INDEX].trim();
                            maxCapacity = Integer.parseInt(segment[MAX_CAPACITY_INDEX].trim());
                            servicePriority = Integer.parseInt(segment[SERVICE_PRIORITY_INDEX].trim());
                        }
                        //Error out
                        catch (NumberFormatException e) {
                            System.out.println("Invalid line format for elevator details: " + line);
                            continue;
                        }
                        //Determine the elevator type
                        switch (elevatorType){
                            case "StandardElevator" -> elevators.add(new StandardElevator(maxCapacity, servicePriority, standardGenServicePriority, numOfFloors));
                            case "ExpressElevator" -> elevators.add(new ExpressElevator(maxCapacity, servicePriority, expressGenServicePriority, numOfFloors));
                            case "FreightElevator" -> elevators.add(new FreightElevator(maxCapacity, servicePriority, freightGenServicePriority, numOfFloors));
                            case "GlassElevator" -> elevators.add(new GlassElevator(maxCapacity, servicePriority, glassGenServicePriority, numOfFloors));
                            default -> {
                            }
                        }
                    }
                }
                elevators.add(elevator);
            }
        }
    }
    public Map<String, Integer> getElevatorRequestPercent() throws FileNotFoundException {
        Map<String, Integer> percentages;
        try (Scanner scanner = new Scanner(file)) {
            scanner.useDelimiter(" ");
            percentages = new HashMap<>();
            while(scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                //Adding request percentage of elevator
                if(line.startsWith("request_percentage")){
                    String[] segment = line.split("\\s+");
                    //Chopping up data stream
                    if (segment.length >= 3){
                        try {
                            String elevatorType = segment[TYPE_INDEX].trim();
                            int genServicePercentage = Integer.parseInt(segment[GENERAL_PERCENTAGE_INDEX ].trim());
                            percentages.put(elevatorType, genServicePercentage);
                        }
                        //Error out
                        catch (NumberFormatException e){
                            System.out.println("Invalid line format for request percentage details: " + line);
                        }
                    }
                }
            }
        }
        return percentages;
    }
        public ArrayList<Elevator> getElevatorInfo(){
        return this.elevators;
    }
}
