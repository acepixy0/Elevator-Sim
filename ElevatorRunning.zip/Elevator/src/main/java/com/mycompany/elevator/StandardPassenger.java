package com.mycompany.Elevator;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class StandardPassenger extends Passenger {
    Random random = new Random();
    
    //Default
    StandardPassenger() {
        super();
        this.setType(PassengerType.STANDARD);
    }
    // Pass parametric data to arrayList
    StandardPassenger(int startFloor,int endFloor){
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(random.nextInt(1, 30 + 1));
       this.setGenRequestPriority(random.nextInt(1, 70 + 1));
       this.setType(PassengerType.STANDARD);
    }
    //Used to store info from file read
    StandardPassenger(int startFloor, int endFloor, int requestPriority, int genRequestPercentage) {
       super();
       this.setStartFloor(startFloor);
       this.setEndFloor(endFloor);
       this.setRequestPriority(requestPriority);
       this.setGenRequestPriority(genRequestPercentage);
       this.setType(PassengerType.STANDARD);
    }
    //Copy
    StandardPassenger(StandardPassenger standardP){
        
    }
    @Override
    public boolean requestElevator(SimulatorSettings settings) {
        System.out.println("Standard Passenger request an elevator");
        return true;
    }

}
