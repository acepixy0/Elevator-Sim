package com.mycompany.Elevator;
import java.util.Objects;
import java.util.Random;
/**
 *
 * @author Nathan J. Hagood
 */
public class FreightElevator extends Elevator{
    Random random = new Random();
    
    //Default
    FreightElevator(){
        super();
        this.setType(ElevatorType.FREIGHT);
    }
    // Pass parametric data to arrayList from file
    FreightElevator(int maxCapacity, int servicePriority, int GenServicePriority, int numOfFloors) {
        super();
        this.setMaxCapacity(maxCapacity);
        this.setServicePriority(servicePriority);
        this.setGenServicePriority(GenServicePriority);
        this.setType(ElevatorType.FREIGHT);
        this.setNumFloors(numOfFloors);
    }
    // Random generated elevator
    FreightElevator(int numFloors){
        super();
        this.setGenServicePriority(random.nextInt(1, 5 + 1));
        this.setServicePriority(random.nextInt(1, 20 + 1));
        this.setMaxCapacity(random.nextInt(2, 15 + 1));
        this.setCurrentFloor(this.getCurrentFloor());
        this.setType(ElevatorType.FREIGHT);
        this.setCurrentFloor(random.nextInt(numFloors) + 1);
    }
    //Copy
    FreightElevator(FreightElevator freightE){
        
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
            if (!(o instanceof FreightElevator)) return false;
                FreightElevator elevator = (FreightElevator) o;
                return getId() == elevator.getId();
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 29 * hash + Objects.hashCode(this.random);
        return hash;
    }
}
